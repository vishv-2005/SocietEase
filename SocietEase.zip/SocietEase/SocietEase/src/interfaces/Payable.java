package interfaces;

public interface Payable {
    double getAmountPaid();
    String getPaymentMode();
}
