package interfaces;

public interface Ownable {
    String getOwner();
}
