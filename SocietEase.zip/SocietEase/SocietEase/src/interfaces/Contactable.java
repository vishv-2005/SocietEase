package interfaces;

public interface Contactable {
    String getContactInfo();
}
