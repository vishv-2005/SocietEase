package storage;

import GUI.ADMIN.AdminWindow;
import GUI.USER.ResidentWindow;
import GUI.UIUtils;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class GUIconnection extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;

    public static void main(String[] args) {
        // Set look and feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Start the application
        SwingUtilities.invokeLater(() -> new GUIconnection());
    }

    public GUIconnection() {
        setTitle("SocietEase - Database Connection");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Apply styling
        UIUtils.styleFrame(this);

        // Create main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);

        // Title
        JLabel titleLabel = new JLabel("Welcome to SocietEase", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Database connection panel
        JPanel connectionPanel = new JPanel();
        connectionPanel.setLayout(new GridBagLayout());
        connectionPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Username
        JLabel userLabel = new JLabel("MySQL Username:");
        UIUtils.styleLabel(userLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        connectionPanel.add(userLabel, gbc);

        usernameField = new JTextField(20);
        UIUtils.styleTextField(usernameField);
        gbc.gridx = 1;
        gbc.gridy = 0;
        connectionPanel.add(usernameField, gbc);

        // Password
        JLabel passLabel = new JLabel("MySQL Password:");
        UIUtils.styleLabel(passLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 1;
        connectionPanel.add(passLabel, gbc);

        //Enter Facility
        usernameField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                passwordField.requestFocus();
            }
        });

        passwordField = new JPasswordField(20);
        UIUtils.styleTextField(passwordField);
        gbc.gridx = 1;
        gbc.gridy = 1;
        connectionPanel.add(passwordField, gbc);

        mainPanel.add(connectionPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Buttons panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setBackground(UIUtils.BACKGROUND_COLOR);

        JButton connectButton = new JButton("Connect");
        UIUtils.styleButton(connectButton);
        connectButton.addActionListener(e -> connectToDatabase());

        JButton exitButton = new JButton("Exit");
        UIUtils.styleButton(exitButton);
        exitButton.setBackground(UIUtils.ACCENT_COLOR);
        exitButton.addActionListener(e -> System.exit(0));

        passwordField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                connectButton.doClick();
            }
        });

        buttonPanel.add(connectButton);
        buttonPanel.add(exitButton);

        mainPanel.add(buttonPanel);

        // Add main panel to frame
        add(mainPanel);
        setVisible(true);
    }

    public void showLoginWindow() {
        JFrame frame = new JFrame("SocietEase - Login");
        frame.setSize(400, 300);
        UIUtils.styleFrame(frame);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);

        // Title
        JLabel titleLabel = new JLabel("Select User Type", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Buttons panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(UIUtils.BACKGROUND_COLOR);

        JButton adminButton = new JButton("ADMIN");
        UIUtils.styleButton(adminButton);
        adminButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        adminButton.addActionListener(e -> {
            new AdminWindow();
            frame.dispose();
        });

        JButton residentButton = new JButton("RESIDENT");
        UIUtils.styleButton(residentButton);
        residentButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        residentButton.addActionListener(e -> {
            new ResidentWindow();
            frame.dispose();
        });

        buttonPanel.add(adminButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(residentButton);

        mainPanel.add(buttonPanel);
        frame.add(mainPanel);

        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    private void connectToDatabase() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        try {
            DBConnector.connect(username, password);
            JOptionPane.showMessageDialog(this,
                    "Connected to Database Successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            dispose();
            showLoginWindow();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Connection Failed: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
