package storage;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import models.*;
import java.util.Scanner;

public class DBConnector {

    private static Connection connection;

    // ✅ Method to connect using GUI credentials
    // New static method for GUI
    public static void connect(String username, String password) throws SQLException, ClassNotFoundException {
        if (connection == null) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/", username, password);

            if (!new DBConnector().isDatabaseExists("SocietEase_HVT")) {
                System.out.println("Database 'SocietEase_HVT' does not exist. Creating the database...");
                new DBConnector().createDatabaseAndTables();
            }

            Statement stmt = connection.createStatement();
            stmt.executeUpdate("USE SocietEase_HVT");
            System.out.println("Database Connection Successful!");
        }
    }

    private static boolean isDatabaseExists(String dbName) throws SQLException {
        ResultSet rs = connection.getMetaData().getCatalogs();
        while (rs.next()) {
            if (rs.getString(1).equalsIgnoreCase(dbName)) {
                return true;
            }
        }
        return false;
    }

    public static Connection getConnection() {
        return connection;
    }

    public static ResultSet getRS(String query) {
        try {
            return connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE).executeQuery(query);
        } catch (SQLException e) {
            System.out.println("Error Message: " + e.getMessage());
            return null;
        }
    }

    public static void closeConnection() {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Create database and tables with sample data
    private static void createDatabaseAndTables() throws SQLException {
        Statement stmt = connection.createStatement();

        // Create the database
        stmt.executeUpdate("CREATE DATABASE SocietEase_HVT");
        stmt.executeUpdate("USE SocietEase_HVT");

        // Create tables
        stmt.executeUpdate("CREATE TABLE Resident (name VARCHAR(100), apartmentNumber INT PRIMARY KEY, contactInformation VARCHAR(100), email VARCHAR(100))");
        stmt.executeUpdate("CREATE TABLE Helper (helperID INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, role VARCHAR(50), aadharNumber BIGINT, contactInformation VARCHAR(100), salary DECIMAL(10, 2))");
        stmt.executeUpdate("CREATE TABLE Maintenance (maintenanceID INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), apartmentNumber INT, contactInformation VARCHAR(100), amountPaid DECIMAL(10, 2), modeOfPayment VARCHAR(50), paymentDate DATE, FOREIGN KEY (apartmentNumber) REFERENCES Resident(apartmentNumber))");
        stmt.executeUpdate("CREATE TABLE Complaint (complaintID INT AUTO_INCREMENT PRIMARY KEY, apartmentNumber INT, description TEXT, dateFiled DATE, status VARCHAR(20) DEFAULT 'Pending', FOREIGN KEY (apartmentNumber) REFERENCES Resident(apartmentNumber))");
        stmt.executeUpdate("CREATE TABLE Committee (committeeID INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), description TEXT, head VARCHAR(100), apartmentNumber INT, FOREIGN KEY (apartmentNumber) REFERENCES Resident(apartmentNumber))");
        stmt.executeUpdate("CREATE TABLE Notice (noticeID INT AUTO_INCREMENT PRIMARY KEY, date DATE, title VARCHAR(200), content TEXT, issuedBy INT, FOREIGN KEY (issuedBy) REFERENCES Committee(committeeID))");
        stmt.executeUpdate("CREATE TABLE Vehicle (number VARCHAR(50) PRIMARY KEY, type VARCHAR(20), owner VARCHAR(100), apartmentNumber INT, FOREIGN KEY (apartmentNumber) REFERENCES Resident(apartmentNumber))");
        stmt.executeUpdate("CREATE TABLE Apartment (apartmentNumber INT PRIMARY KEY, type VARCHAR(50), name VARCHAR(100))");
        stmt.executeUpdate("CREATE TABLE Apartment_Helper( apartmentNumber INT, helperID INT, PRIMARY KEY (apartmentNumber, helperID), FOREIGN KEY (apartmentNumber) REFERENCES Apartment(apartmentNumber), FOREIGN KEY (helperID) REFERENCES Helper(helperID) ON DELETE CASCADE)");
        // Insert sample data
        stmt.executeUpdate("INSERT INTO Resident (name, apartmentNumber, contactInformation, email) VALUES "
                + "('Ravi Sharma', 101, '9876543210', 'ravi.sharma@gmail.com'),"
                + "('Neha Patel', 102, '9865432109', 'neha.patel@yahoo.com'),"
                + "('Vikram Sinha', 103, '9765432108', 'vikram.sinha@hotmail.com'),"
                + "('Hem Gabhawala', 104, '9898123456', 'hem.104@gmail.com'),"
                + "('Hir Ray', 201, '9787654321', 'hir.201@yahoo.com'),"
                + "('Thira Patel', 202, '9678563412', 'thira.202@outlook.com'),"
                + "('Henisha Mistry', 203, '9856473829', 'henisha.mistry@rediffmail.com'),"
                + "('Vishv Patel', 204, '9765342187', 'vishv.204@hotmail.com'),"
                + "('Chirayu Mistry', 301, '9896321475', 'chirayu.301@gmail.com'),"
                + "('Meet Suthar', 302, '9872316548', 'meet.302@yahoo.com'),"
                + "('Hardi Patel', 303, '9768451290', 'hardi.303@outlook.com'),"
                + "('Hardi Parikh', 304, '9687123549', 'hardi.parikh@gmail.com'),"
                + "('Shubham Parikh', 401, '9865412378', 'shubham.401@yahoo.com'),"
                + "('Diti Amin', 402, '9798564123', 'diti.402@rediffmail.com'),"
                + "('Shreya Jadhav', 403, '9876598231', 'shreya.403@hotmail.com'),"
                + "('Tithi Patel', 404, '9654781236', 'tithi.404@gmail.com'),"
                + "('Vivek Sir', 501, '9784123654', 'vivek.sir501@outlook.com'),"
                + "('Avani Mam', 502, '9865324781', 'avani.mam502@yahoo.com'),"
                + "('Maharshi Bhrambhatt', 503, '9678521436', 'maharshi.503@gmail.com'),"
                + "('Preet Amin', 504, '9874563219', 'preet.504@hotmail.com');"
        );

        stmt.executeUpdate("INSERT INTO Helper (name, role, aadharNumber, contactInformation, salary) VALUES "
                + "('Ramesh Kumar', 'Security Guard', 123456789012, '9876543210', 15000.00),"
                + "('Suresh Yadav', 'Cleaner', 123456789013, '9865432109', 12000.00),"
                + "('Manju Devi', 'Maid', 123456789014, '9765432108', 10000.00),"
                + "('Anita Sharma', 'Cook', 123456789015, '9856321470', 11000.00),"
                + "('Sunil Verma', 'Electrician', 123456789016, '9845213698', 16000.00),"
                + "('Geeta Rani', 'Gardener', 123456789017, '9834567890', 9500.00),"
                + "('Vikram Singh', 'Plumber', 123456789018, '9823456781', 14000.00)");

        stmt.executeUpdate("INSERT INTO Committee (name, description, head, apartmentNumber) VALUES "
                + "('Maintenance', 'Handles maintenance and repair work.', 'Ravi Sharma', 101),"
                + "('Event', 'Organizes cultural and social events.', 'Neha Patel', 102),"
                + "('Security', 'Ensures society safety and security.', 'Vikram Sinha', 103);");

        stmt.executeUpdate("INSERT INTO Notice (date, title, content, issuedBy) VALUES "
                + "('2025-01-15', 'Water Supply', 'Water supply will be disrupted from 9 AM to 5 PM.', '1'),"
                + "('2025-01-20', 'Parking Rules', 'No double parking allowed.', '3'),"
                + "('2025-01-25', 'Maintenance Due', 'Submit maintenance payments by 31st Jan.', '3'),"
                + "('2025-02-01', 'Fire Drill', 'Mandatory fire drill scheduled on 3rd Feb at 10 AM.', '2'),"
                + "('2025-02-05', 'Lift Maintenance', 'Lifts in Block B will be under maintenance on 6th Feb.', '1'),"
                + "('2025-02-10', 'Society Meeting', 'All residents are invited to the society meeting on 12th Feb.', '1'),"
                + "('2025-02-15', 'Playground Cleaning', 'Playground will be closed for cleaning from 8 AM to 12 PM.', '2')");

//        stmt.executeUpdate("INSERT INTO Notice (date, title, content, issuedBy) VALUES "
//                + "('2025-01-15', 'Water Supply', 'Water supply will be disrupted from 9 AM to 5 PM.', '1'),"
//                + "('2025-01-20', 'Parking Rules', 'No double parking allowed.', '3'),"
//                + "('2025-01-25', 'Maintenance Due', 'Submit maintenance payments by 31st Jan.', '3')");
        
        stmt.executeUpdate("INSERT INTO Maintenance (name, apartmentNumber, contactInformation, amountPaid, modeOfPayment, paymentDate) VALUES "
                + "('Ravi Sharma', 101, '9876543210', 5000.00, 'Online', '2025-01-10'),"
                + "('Neha Patel', 102, '9865432109', 4500.00, 'Cheque', '2025-01-12'),"
                + "('Vikram Sinha', 103, '9765432108', 4000.00, 'Cash', '2025-01-15');");

        stmt.executeUpdate("INSERT INTO Complaint (apartmentNumber, description, dateFiled) VALUES "
                + "(101, 'Water leakage in bathroom.', '2025-01-20'),"
                + "(102, 'Noise disturbance from neighbors.', '2025-01-22'),"
                + "(103, 'Lift not working.', '2025-01-25');");

        stmt.executeUpdate("INSERT INTO Vehicle (number, type, owner, apartmentNumber) VALUES "
                + "('GJ01AB1234', 'Car', 'Ravi Sharma', 101), "
                + "('GJ01CD5678', 'Bike', 'Neha Patel', 102), "
                + "('GJ01EF9012', 'Car', 'Vikram Sinha', 103), "
                + "('GJ01GH3456', 'Scooter', 'Hem Gabbawala', 104), "
                + "('GJ01IJ7890', 'Car', 'Hir Ray', 201), "
                + "('GJ02KL1234', 'Bike', 'Thira Patel', 202), "
                + "('GJ02MN5678', 'Car', 'Rudra Soni', 203), "
                + "('GJ02OP9012', 'Scooter', 'Vishv Patel', 204), "
                + "('GJ02QR3456', 'Car', 'Chirayu Vaghela', 301), "
                + "('GJ02ST7890', 'Bike', 'Meet Suthar', 302), "
                + "('GJ03UV1234', 'Car', 'Hardi Patel', 303), "
                + "('GJ03WX5678', 'Bike', 'Hardi Parikh', 304), "
                + "('GJ03YZ9012', 'Car', 'Shubham Parikh', 401), "
                + "('GJ03AB3456', 'Scooter', 'Diti Amin', 402), "
                + "('GJ03CD7890', 'Car', 'Shreya Jadhav', 403), "
                + "('GJ04EF1234', 'Bike', 'Tithi Patel', 404), "
                + "('GJ04GH5678', 'Car', 'Vivek Sir', 501), "
                + "('GJ04IJ9012', 'Scooter', 'Avani Mam', 502), "
                + "('GJ04KL3456', 'Car', 'Maharishi', 503), "
                + "('GJ04MN7890', 'Car', 'Preet Amin', 504), "
                + "('GJ05OP1234', 'Bike', 'Ravi Sharma', 101), "
                + "('GJ05QR5678', 'Scooter', 'Neha Patel', 102), "
                + "('GJ05ST9012', 'Car', 'Vikram Sinha', 103), "
                + "('GJ05UV3456', 'Bike', 'Hem Gabbawala', 104), "
                + "('GJ05WX7890', 'Car', 'Hir Ray', 201);");
        
        stmt.executeUpdate("INSERT INTO Apartment (apartmentNumber, type, name) VALUES "
                + "(101, 'Owner', 'Ravi Sharma'),"
                + "(102, 'Owner', 'Neha Patel'),"
                + "(103, 'Tenant', 'Vikram Sinha'),"
                + "(104, 'Tenant', 'Hem'),"
                + "(201, 'Owner', 'Hir'),"
                + "(202, 'Tenant', 'Thira'),"
                + "(203, 'Owner', 'Henisha Mistry'),"
                + "(204, 'Owner', 'Vishv'),"
                + "(301, 'Tenant', 'Chirayu'),"
                + "(302, 'Owner', 'Meet'),"
                + "(303, 'Owner', 'Hardi'),"
                + "(304, 'Owner', 'Hardi Parikh'),"
                + "(401, 'Tenant', 'Shubham'),"
                + "(402, 'Tenant', 'Diti'),"
                + "(403, 'Owner', 'Shreya'),"
                + "(404, 'Owner', 'Tithi'),"
                + "(501, 'Tenant', 'Vivek Sir'),"
                + "(502, 'Tenant', 'Avani Mam'),"
                + "(503, 'Owner', 'Maharshi'),"
                + "(504, 'Owner', 'Preet');");

        System.out.println("Database and tables created successfully with sample data!");
    }

    public static void updateApartmentAndResident(String apartmentNumber, String type, String name, String contact, String email) {
        String apartmentQuery = "UPDATE apartment SET type = ?, name = ? WHERE apartmentNumber = ?";
        String residentQuery = "UPDATE resident SET name = ?, contactInformation = ?, email = ? WHERE apartmentNumber = ?";

        try (PreparedStatement pstmtApt = connection.prepareStatement(apartmentQuery);
                PreparedStatement pstmtRes = connection.prepareStatement(residentQuery)) {

            connection.setAutoCommit(false); // Start transaction

            // Update Apartment
            pstmtApt.setString(1, type);
            pstmtApt.setString(2, name);
            pstmtApt.setString(3, apartmentNumber);
            pstmtApt.executeUpdate();

            // Update Resident
            pstmtRes.setString(1, name);
            pstmtRes.setString(2, contact);
            pstmtRes.setString(3, email);
            pstmtRes.setString(4, apartmentNumber);
            pstmtRes.executeUpdate();

            connection.commit(); // Commit transaction
            System.out.println("Apartment and Resident updated successfully!");

        } catch (SQLException e) {
            try {
                connection.rollback(); // Rollback in case of error
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void updateApartment(String apartmentNumber, String type, String name, String contact, String email) {
        String apartmentQuery = "UPDATE apartment SET type = ?, name = ? WHERE apartmentNumber = ?";
        String residentQuery = "UPDATE resident SET name = ?, contactInformation = ?, email = ? WHERE apartmentNumber = ?";

        try (PreparedStatement pstmtApt = connection.prepareStatement(apartmentQuery);
                PreparedStatement pstmtRes = connection.prepareStatement(residentQuery)) {

            connection.setAutoCommit(false);

            // Update Apartment
            pstmtApt.setString(1, type);
            pstmtApt.setString(2, name);
            pstmtApt.setString(3, apartmentNumber);
            pstmtApt.executeUpdate();

            // Update Resident Contact & Email
            pstmtRes.setString(1, name);
            pstmtRes.setString(2, contact);
            pstmtRes.setString(3, email);
            pstmtRes.setString(4, apartmentNumber);
            pstmtRes.executeUpdate();

            connection.commit();
            System.out.println("Apartment and Resident contact details updated successfully!");

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static List<Apartment> getAllApartments() {
        List<Apartment> apartments = new ArrayList<>();
        String query = "SELECT * FROM Apartment";
        try (ResultSet rs = getRS(query)) {
            while (rs.next()) {
                Apartment apartment = new Apartment();
                apartment.setApartmentNumber(String.valueOf(rs.getInt("apartmentNumber")));
                apartment.setType(rs.getString("type"));
                apartment.setName(rs.getString("name"));
                apartments.add(apartment);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving apartments: " + e.getMessage());
        }
        return apartments;
    }

    public static Apartment getApartmentByNumber(String apartmentNumber) {
        String query = "SELECT * FROM Apartment WHERE apartmentNumber = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, Integer.parseInt(apartmentNumber));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Apartment apartment = new Apartment();
                    apartment.setApartmentNumber(String.valueOf(rs.getInt("apartmentNumber")));
                    apartment.setType(rs.getString("type"));
                    apartment.setName(rs.getString("name"));
                    return apartment;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving apartment: " + e.getMessage());
        }
        return null;
    }

    // --- Committee Storage Methods ---
    public static void addCommittee(Committee committee) {
        String query = "INSERT INTO Committee (name, description, head, apartmentNumber) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, committee.getName());
            stmt.setString(2, committee.getDescription());
            stmt.setString(3, committee.getHead());
            stmt.setString(4, committee.getApartmentNumber());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error adding committee: " + e.getMessage());
        }
    }

    public static void removeCommittee(String committeeID) {
        String query = "DELETE FROM Committee WHERE committeeID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, committeeID);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error removing committee: " + e.getMessage());
        }
    }

    public static List<Committee> getAllCommittees() {
        List<Committee> committees = new ArrayList<>();
        String query = "SELECT * FROM Committee";
        try (ResultSet rs = getRS(query)) {
            while (rs.next()) {
                Committee committee = new Committee();
                committee.setCommitteeID(rs.getString("committeeID"));
                committee.setName(rs.getString("name"));
                committee.setDescription(rs.getString("description"));
                committee.setHead(rs.getString("head"));
                committee.setApartmentNumber(rs.getString("apartmentNumber"));
                committees.add(committee);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving committees: " + e.getMessage());
        }
        return committees;
    }

    // --- Complaint Storage Methods ---
    public static void addComplaint(Complaint complaint) {
        String query = "INSERT INTO Complaint (apartmentNumber, description, dateFiled) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, complaint.getApartmentNumber());
            stmt.setString(2, complaint.getDescription());
            stmt.setDate(3, Date.valueOf(complaint.getDateFiled()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error adding complaint: " + e.getMessage());
        }
    }

    public static List<Complaint> getAllComplaints() {
        List<Complaint> complaints = new ArrayList<>();
        String query = "SELECT * FROM Complaint";
        try (ResultSet rs = getRS(query)) {
            while (rs.next()) {
                Complaint complaint = new Complaint();
                complaint.setComplaintID(rs.getString("complaintID"));
                complaint.setApartmentNumber(rs.getString("apartmentNumber"));
                complaint.setDescription(rs.getString("description"));
                complaint.setDateFiled(rs.getDate("dateFiled").toLocalDate());

                complaints.add(complaint);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving complaints: " + e.getMessage());
        }
        return complaints;
    }

    public static void resolveAndDeleteComplaint(int complaintID) {
        String query = "DELETE FROM Complaint WHERE complaintID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, complaintID);
            stmt.executeUpdate();
            System.out.println("Complaint resolved and deleted successfully.");
        } catch (SQLException e) {
            System.out.println("Error deleting resolved complaint: " + e.getMessage());
        }
    }

    // --- Notice Storage Methods ---
    public static boolean addNotice(Notice notice) {
        String query = "INSERT INTO Notice (date, title, content, issuedBy) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, Date.valueOf(notice.getDate()));
            stmt.setString(2, notice.getTitle());
            stmt.setString(3, notice.getContent());
            stmt.setInt(4, notice.getIssuedBy());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error inserting notice: " + e.getMessage());
            return false;
        }
    }

    public static List<Notice> getAllNotices() {
        List<Notice> notices = new ArrayList<>();
        String query = "SELECT * FROM Notice";
        try (ResultSet rs = getRS(query)) {
            while (rs.next()) {
                Notice notice = new Notice();
                notice.setNoticeID(rs.getString("noticeID"));
                notice.setDate(rs.getDate("date").toLocalDate());
                notice.setTitle(rs.getString("title"));
                notice.setContent(rs.getString("content"));
                notice.setIssuedBy(rs.getInt("issuedBy"));
                notices.add(notice);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving notices: " + e.getMessage());
        }
        return notices;
    }

    public static boolean assignHelperToApartment(String apartmentNumber, String helperID) {
        String query = "INSERT INTO Apartment_Helper (apartmentNumber, helperID) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, apartmentNumber);
            stmt.setString(2, helperID);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error assigning helper: " + e.getMessage());
            return false;
        }
    }

    public static List<Helper> getHelpersForApartment(String apartmentNumber) {
        List<Helper> helpers = new ArrayList<>();
        String query = "SELECT h.* FROM Helper h JOIN Apartment_Helper ah ON h.helperID = ah.helperID WHERE ah.apartmentNumber = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, apartmentNumber);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Helper h = new Helper();
                h.setHelperID(rs.getString("helperID"));
                h.setName(rs.getString("name"));
                h.setRole(rs.getString("role"));
                h.setContactInfo(rs.getString("contactInformation"));
                h.setAadharNumber(rs.getLong("aadharNumber"));
                h.setSalary(rs.getDouble("salary"));
                helpers.add(h);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error fetching helpers: " + e.getMessage());
        }
        return helpers;
    }

    public static boolean unassignHelperFromApartment(String apartmentNumber, String helperID) {
        String query = "DELETE FROM Apartment_Helper WHERE apartmentNumber = ? AND helperID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, apartmentNumber);
            stmt.setString(2, helperID);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("Error unassigning helper: " + e.getMessage());
            return false;
        }
    }

    // --- Helper Storage Methods ---
    public static boolean addHelper(Helper helper) {
        String query = "INSERT INTO helper (name, role, aadharNumber, contactInformation, salary) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, helper.getName());
            stmt.setString(2, helper.getRole());
            stmt.setLong(3, helper.getAadharNumber());
            stmt.setString(4, helper.getContactInfo());
            stmt.setDouble(5, helper.getSalary());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("❌ DB Error (Add Helper): " + e.getMessage());
            return false;
        }
    }

    public static boolean removeHelperByID(String helperID) {
        String query = "DELETE FROM Helper WHERE helperID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, Integer.parseInt(helperID));
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("Error removing helper: " + e.getMessage());
            return false;
        }
    }

    public static boolean removeHelperIfUnassigned(String helperID) {
        String checkQuery = "SELECT * FROM Apartment_Helper WHERE helperID = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
            checkStmt.setString(1, helperID);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                System.out.println("❌ Cannot remove helper. They are still assigned to an apartment.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error checking helper assignment: " + e.getMessage());
            return false;
        }

        String deleteQuery = "DELETE FROM Helper WHERE helperID = ?";
        try (PreparedStatement deleteStmt = connection.prepareStatement(deleteQuery)) {
            deleteStmt.setString(1, helperID);
            int rows = deleteStmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("Error deleting helper: " + e.getMessage());
            return false;
        }
    }

    public static List<Helper> getAllHelpers() {
        List<Helper> helpers = new ArrayList<>();
        String query = "SELECT * FROM Helper";
        try (ResultSet rs = getRS(query)) {
            while (rs.next()) {
                Helper helper = new Helper();

                helper.setHelperID(rs.getString("helperID"));
                helper.setName(rs.getString("name"));
                helper.setRole(rs.getString("role"));
                helper.setAadharNumber(rs.getLong("aadharNumber"));
                helper.setContactInfo(rs.getString("contactInformation"));
                helper.setSalary(rs.getDouble("salary"));
                helpers.add(helper);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving helpers: " + e.getMessage());
        }
        return helpers;
    }

    // --- Maintenance Storage Methods ---
    public static void addMaintenanceRecord(Maintenance maintenance) {
        String query = "INSERT INTO Maintenance (name, apartmentNumber, contactInformation, amountPaid, modeOfPayment, paymentDate) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, maintenance.getName());
            stmt.setString(2, maintenance.getApartmentNumber());
            stmt.setString(3, maintenance.getContactInfo());
            stmt.setDouble(4, maintenance.getAmountPaid());
            stmt.setString(5, maintenance.getModeOfPayment());
            stmt.setDate(6, Date.valueOf(maintenance.getPaymentDate()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error adding maintenance record: " + e.getMessage());
        }
    }

    public static List<Maintenance> getAllMaintenanceRecords() {
        List<Maintenance> maintenanceRecords = new ArrayList<>();
        String query = "SELECT * FROM Maintenance";
        try (ResultSet rs = getRS(query)) {
            while (rs.next()) {
                Maintenance maintenance = new Maintenance();
                maintenance.setMaintenanceID(rs.getString("maintenanceID"));
                maintenance.setName(rs.getString("name"));
                maintenance.setApartmentNumber(rs.getString("apartmentNumber"));
                maintenance.setContactInfo(rs.getString("contactInformation"));
                maintenance.setAmountPaid(rs.getDouble("amountPaid"));
                maintenance.setModeOfPayment(rs.getString("modeOfPayment"));
                maintenance.setPaymentDate(rs.getDate("paymentDate").toLocalDate());
                maintenanceRecords.add(maintenance);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving maintenance records: " + e.getMessage());
        }
        return maintenanceRecords;
    }

    // --- Resident Storage Methods ---
    // Function to update only Resident and sync Apartment type
    public static void updateResident(String apartmentNumber, String name, String contact, String email, String type) {
        String residentQuery = "UPDATE resident SET name = ?, contactInformation = ?, email = ? WHERE apartmentNumber = ?";
        String apartmentQuery = "UPDATE apartment SET name = ?, type = ? WHERE apartmentNumber = ?";

        try (PreparedStatement pstmtRes = connection.prepareStatement(residentQuery);
                PreparedStatement pstmtApt = connection.prepareStatement(apartmentQuery)) {

            connection.setAutoCommit(false);

            // Update Resident
            pstmtRes.setString(1, name);
            pstmtRes.setString(2, contact);
            pstmtRes.setString(3, email);
            pstmtRes.setString(4, apartmentNumber);
            pstmtRes.executeUpdate();

            // Update Apartment Type
            pstmtApt.setString(1, name);
            pstmtApt.setString(2, type);
            pstmtApt.setString(3, apartmentNumber);
            pstmtApt.executeUpdate();

            connection.commit();
            System.out.println("Resident and Apartment type updated successfully!");

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Function to remove resident and set apartment values to NULL
    public static boolean removeResident(String apartmentNumber) {
        String residentQuery = "Update resident SET name = NULL, contactInformation = NULL, email = NULL WHERE apartmentNumber = ?";
        String apartmentQuery = "UPDATE apartment SET type = NULL, name = NULL WHERE apartmentNumber = ?";

        try (PreparedStatement pstmtApt = connection.prepareStatement(apartmentQuery);
                PreparedStatement pstmtRes = connection.prepareStatement(residentQuery)) {

            connection.setAutoCommit(false);

            // Nullify Apartment Data
            pstmtApt.setString(1, apartmentNumber);
            int apartmentUpdated = pstmtApt.executeUpdate();

            // Remove Resident
            pstmtRes.setString(1, apartmentNumber);
            int residentRemoved = pstmtRes.executeUpdate();

            if (residentRemoved > 0) {
                connection.commit();
                System.out.println("Resident removed and apartment updated successfully!");
                return true;  // ✅ Return true if deletion was successful
            } else {
                connection.rollback();
                System.out.println("No resident found with the given name.");
                return false; // ❌ Return false if resident doesn't exist
            }

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            e.printStackTrace();
            return false; // ❌ Return false on error
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void clearApartmentResident(String apartmentNumber) {
        String query = "UPDATE apartment SET type = NULL, name = NULL WHERE apartmentNumber = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, apartmentNumber);
            int updatedRows = pstmt.executeUpdate();

            if (updatedRows > 0) {
                System.out.println("Apartment details cleared.");
            } else {
                System.out.println("No apartment found for the given number.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Resident> getAllResidents() {
        List<Resident> residents = new ArrayList<>();
        String query = "SELECT * FROM Resident";
        try (ResultSet rs = getRS(query)) {
            while (rs.next()) {
                // 🔹 Fix: Use constructor instead of setApartmentNumber()
                Resident resident = new Resident(
                        rs.getString("name"),
                        rs.getString("contactInformation"),
                        rs.getString("apartmentNumber"), // Directly pass apartmentNumber
                        rs.getString("email")
                );
                residents.add(resident);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving residents: " + e.getMessage());
        }
        return residents;
    }

    public static Resident getResidentByNumber(String apartmentNumber) {
        String query = "SELECT * FROM Resident WHERE apartmentNumber = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, Integer.parseInt(apartmentNumber));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // 🔹 Fix: Use the constructor instead of setApartmentNumber()
                    return new Resident(
                            rs.getString("name"),
                            rs.getString("contactInformation"),
                            rs.getString("apartmentNumber"), // Directly pass apartmentNumber
                            rs.getString("email")
                    );
                }
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving apartment: " + e.getMessage());
        }
        return null;
    }

    // --- Vehicle Storage Methods ---
    public static void addVehicle(Vehicle vehicle) {
        String query = "INSERT INTO Vehicle (number, type, owner, apartmentNumber) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, vehicle.getRegistrationNumber());
            stmt.setString(2, vehicle.getType());
            stmt.setString(3, vehicle.getOwnerName());
            stmt.setInt(4, Integer.parseInt(vehicle.getApartmentNumber()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error adding vehicle: " + e.getMessage());
        }
    }

    public static void removeVehicle(String registrationNumber) {
        String query = "DELETE FROM Vehicle WHERE number = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, registrationNumber);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error removing vehicle: " + e.getMessage());
        }
    }

    public static List<Vehicle> getAllVehicles() {
        List<Vehicle> vehicles = new ArrayList<>();
        String query = "SELECT * FROM Vehicle";
        try (ResultSet rs = getRS(query)) {
            while (rs.next()) {
                Vehicle vehicle = new Vehicle();
                vehicle.setRegistrationNumber(rs.getString("number"));
                vehicle.setType(rs.getString("type"));
                vehicle.setOwnerName(rs.getString("owner"));
                vehicle.setApartmentNumber(String.valueOf(rs.getInt("apartmentNumber")));
                vehicles.add(vehicle);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving vehicles: " + e.getMessage());
        }
        return vehicles;
    }

    public static List<Vehicle> getUserVehicles(String apartmentNumber) {
        List<Vehicle> userVehicles = new ArrayList<>();
        String query = "SELECT * FROM Vehicle WHERE apartmentNumber = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, Integer.parseInt(apartmentNumber));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Vehicle vehicle = new Vehicle();
                    vehicle.setRegistrationNumber(rs.getString("number"));
                    vehicle.setType(rs.getString("type"));
                    vehicle.setOwnerName(rs.getString("owner"));
                    vehicle.setApartmentNumber(String.valueOf(rs.getInt("apartmentNumber")));
                    userVehicles.add(vehicle);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving user vehicles: " + e.getMessage());
        }
        return userVehicles;
    }
}
