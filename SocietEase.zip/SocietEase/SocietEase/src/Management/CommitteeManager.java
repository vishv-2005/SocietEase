package Management;

import models.Committee;
import storage.DBConnector;
import java.util.List;

public class CommitteeManager {
    public void createCommittee(String name, String head, String apartmentNumber, String description) {
        Committee committee = new Committee();
        committee.setName(name);
        committee.setHead(head);
        committee.setApartmentNumber(apartmentNumber);
        committee.setDescription(description);
        DBConnector.addCommittee(committee);
    }

    public void viewAllCommittees() {
        List<Committee> committees = DBConnector.getAllCommittees();
        if (committees.isEmpty()) {
            System.out.println("No committees found.");
        } else {
            for (Committee comm : committees) {
                System.out.println("Name: " + comm.getName() + ", Head: " + comm.getHead() + "Apt: " + comm.getApartmentNumber() + ", Description: " + comm.getDescription());
            }
        }
    }
}
