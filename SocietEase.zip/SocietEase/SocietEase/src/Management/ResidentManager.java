package Management;

import models.Resident;
import models.Apartment;
import storage.DBConnector;
import java.util.List;

public class ResidentManager {

    // **Update Resident Information**
    public static void updateResident(String apartmentNumber, String type, String name, String contact, String email) {
    Resident resident = DBConnector.getResidentByNumber(apartmentNumber); // Fetch resident

    if (resident == null) {
        System.out.println("Error: No resident found for Apartment Number " + apartmentNumber);
        return;
    }

    // Update resident details
    resident.setName(name);
    resident.setContactInfo(contact);
    resident.setEmail(email);

    // Sync with apartment
    Apartment apartment = DBConnector.getApartmentByNumber(apartmentNumber);
    apartment.setType(type);
   
        DBConnector.updateApartment(apartmentNumber, type, name, contact, email);
        DBConnector.updateResident(apartmentNumber, name, contact, email, apartment.getType());
       
        DBConnector.updateResident(apartmentNumber, name, contact, email, type); // Handle missing apartment case
       

    System.out.println("Resident and Apartment updated successfully!");
}


    // **Get Resident by Apartment Number**
    public Resident getResidentByNumber(String apartmentNumber) {
        return DBConnector.getResidentByNumber(apartmentNumber);
    }

    // **Remove Resident (Set Apartment Fields to NULL)**
   public boolean removeResident(String apartmentNumber) {
    Resident resident = DBConnector.getResidentByNumber(apartmentNumber);
    
    if (resident == null) {
        System.out.println("Error: No resident found for Apartment Number " + apartmentNumber);
        return false;
    }

    // Remove resident and check if successful
    boolean removed = DBConnector.removeResident(apartmentNumber);
    
    if (removed) {
        // Set apartment details to NULL except apartment number
        DBConnector.clearApartmentResident(apartmentNumber);
        System.out.println("Resident removed and Apartment details cleared.");
    } else {
        System.out.println("Failed to remove resident.");
    }

    return removed;
}


    // **View All Residents**
    public void viewAllResidents() {
        List<Resident> residents = DBConnector.getAllResidents();
        if (residents.isEmpty()) {
            System.out.println("No residents found.");
        } else {
            for (Resident r : residents) {
                System.out.println("Name: " + r.getName() + ", Apt: " + r.getApartmentNumber() +
                        ", Contact: " + r.getContactInfo() + ", Email: " + r.getEmail());
            }
        }
    }
}
