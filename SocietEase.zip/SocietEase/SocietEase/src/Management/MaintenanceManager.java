/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Management;

/**
 *
 * @author apple@Hem
 */

import models.Maintenance;
import storage.DBConnector;
import java.time.LocalDate;
import java.util.List;

public class MaintenanceManager {
    public void payMaintenance(String name, String apartmentNumber, double amount, String mode, String contactInfo) {
        Maintenance maintenance = new Maintenance();
        
        maintenance.setName(name);
        maintenance.setApartmentNumber((apartmentNumber));
        maintenance.setAmountPaid(amount);
        maintenance.setModeOfPayment(mode);
        maintenance.setContactInfo(contactInfo);
        maintenance.setPaymentDate(LocalDate.now());
        DBConnector.addMaintenanceRecord(maintenance);
    }

    public void viewMaintenanceRecords() {
        List<Maintenance> records = DBConnector.getAllMaintenanceRecords();
        if (records.isEmpty()) {
            System.out.println("No maintenance records found.");
        } else {
            for (Maintenance m : records) {
                System.out.println("Name: " + m.getName() + ", Apt: " + m.getApartmentNumber() + ", Amount: " + m.getAmountPaid() + ", Mode: " + m.getModeOfPayment() + ", Contact: " + m.getContactInfo() + ", Date: " + m.getPaymentDate());
            }
        }
    }
}
