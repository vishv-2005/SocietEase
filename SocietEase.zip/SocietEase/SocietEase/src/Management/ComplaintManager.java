/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Management;

/**
 *
 * @author apple@Hem
 */
import models.Complaint;
import storage.DBConnector;
import java.time.LocalDate;
import java.util.List;

public class ComplaintManager {
    public void fileComplaint(String apartmentNumber, String description) {
        Complaint complaint = new Complaint();
        complaint.setApartmentNumber(apartmentNumber);
        complaint.setDescription(description);
        complaint.setDateFiled(LocalDate.now());
        DBConnector.addComplaint(complaint);
    }

    public void viewAllComplaints() {
        List<Complaint> complaints = DBConnector.getAllComplaints();
        if (complaints.isEmpty()) {
            System.out.println("No complaints found.");
        } else {
            for (Complaint comp : complaints) {
                System.out.println("Apt: " + comp.getApartmentNumber() + ", Desc: " + comp.getDescription() + ", Date: " + comp.getDateFiled() + ", Status: " + comp.isResolved());
            }
        }
    }

    public void resolveComplaint(int id) {
    DBConnector.resolveAndDeleteComplaint(id);
}

}
