package Management;

import models.Apartment;
import models.Resident;
import storage.DBConnector;
import java.util.List;

public class ApartmentManager {

    // **Update Apartment Information & Sync Resident**
    public void updateApartment(String apartmentNumber, String name, String type, String contact, String email) {
        Apartment apartment = DBConnector.getApartmentByNumber(apartmentNumber);

        if (apartment == null) {
            System.out.println("Error: No apartment found for Apartment Number " + apartmentNumber);
            return;
        }

        // Update apartment type
        apartment.setType(type);

        // Fetch associated Resident
        Resident resident = DBConnector.getResidentByNumber(apartmentNumber);
        if (resident != null) {
            // Update Resident contact & email if Apartment is updated
            resident.setName(name);
            resident.setContactInfo(contact);
            resident.setEmail(email);
            DBConnector.updateResident(apartmentNumber, name, contact, email, type);
        } else {
            System.out.println("Warning: No resident found for this apartment.");
        }

        // Update Apartment in DB
        DBConnector.updateApartment(apartmentNumber, type, name , contact, email);
        System.out.println("Apartment and associated Resident updated successfully!");
    }

    // **Get Apartment by Number**
    public Apartment getApartmentByNumber(String apartmentNumber) {
        return DBConnector.getApartmentByNumber(apartmentNumber);
    }

    // **View All Apartments**
    public void viewAllApartments() {
        List<Apartment> apartments = DBConnector.getAllApartments();
        if (apartments.isEmpty()) {
            System.out.println("No apartments found.");
        } else {
            for (Apartment apt : apartments) {
                System.out.println("Number: " + apt.getApartmentNumber() + ", Type: " + apt.getType() + ", Name: " + apt.getName());
            }
        }
    }

    // **View Apartment by Number**
    public void viewApartmentByNumber(String apartmentNumber) {
        Apartment apt = DBConnector.getApartmentByNumber(apartmentNumber);
        if (apt != null) {
            System.out.println("Number: " + apt.getApartmentNumber() + ", Type: " + apt.getType() + ", Name: " + apt.getName());
        } else {
            System.out.println("Apartment not found.");
        }
    }
}
