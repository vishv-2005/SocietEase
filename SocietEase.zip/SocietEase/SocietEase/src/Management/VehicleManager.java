/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Management;

/**
 *
 * @author apple@Hem,Vishv,Tithi
 */


import models.Vehicle;
import storage.DBConnector;
import java.util.List;

public class VehicleManager {
    public void addVehicle(String regNo, String aptNo, String owner, String type) {
        Vehicle vehicle = new Vehicle();
        vehicle.setRegistrationNumber(regNo);
        vehicle.setApartmentNumber(aptNo);
        vehicle.setOwnerName(owner);
        vehicle.setType(type);
        DBConnector.addVehicle(vehicle);
    }

    public void removeVehicle(String registrationNumber) {
        DBConnector.removeVehicle(registrationNumber);
    }

    public void viewAllVehicles() {
        List<Vehicle> vehicles = DBConnector.getAllVehicles();
        if (vehicles.isEmpty()) {
            System.out.println("No vehicles found.");
        } else {
            for (Vehicle v : vehicles) {
                System.out.println("Reg No: " + v.getRegistrationNumber() + ", Type: " + v.getType() + ", Owner: " + v.getOwnerName() + ", Apt: " + v.getApartmentNumber());
            }
        }
    }

    public void viewUserVehicles(String apartmentNumber) {
        List<Vehicle> vehicles = DBConnector.getUserVehicles(apartmentNumber);
        if (vehicles.isEmpty()) {
            System.out.println("No vehicles found for apartment " + apartmentNumber);
        } else {
            for (Vehicle v : vehicles) {
                System.out.println("Reg No: " + v.getRegistrationNumber() + ", Type: " + v.getType() + ", Owner: " + v.getOwnerName());
            }
        }
    }
}