/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Management;

/**
 *
 * @author apple@Hem
 */


import models.Notice;
import storage.DBConnector;
import java.time.LocalDate;
import java.util.List;

public class NoticeManager {
    public void issueNotice(String title, String content, int issuedBy) {
        Notice notice = new Notice();
        notice.setDate(LocalDate.now());
        notice.setTitle(title);
        notice.setContent(content); // Assuming admin issues notices
        notice.setIssuedBy(issuedBy);
        DBConnector.addNotice(notice);
    }

    public void viewNotices() {
        List<Notice> notices = DBConnector.getAllNotices();
        if (notices.isEmpty()) {
            System.out.println("No notices found.");
        } else {
            for (Notice n : notices) {
                System.out.println("Date: " + n.getDate() + ", Title: " + n.getTitle() + ", Content: " + n.getContent() + ", IssuedBy: " + n.getIssuedBy());
            }
        }
    }
}
