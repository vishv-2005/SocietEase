package Management;

import models.Helper;
import storage.DBConnector;
import java.util.List;

public class HelperManager {
    public void addHelper(String name, String role, double salary, String contactInfo, long aadharNumber) {
        Helper helper = new Helper();
        helper.setName(name);
        helper.setRole(role);
        helper.setSalary(salary);
        helper.setContactInfo(contactInfo);
        helper.setAadharNumber(aadharNumber);
        DBConnector.addHelper(helper);
    }

    public void removeHelper(String helperID) {
        
        DBConnector.removeHelperByID(helperID);
    }

    public void viewHelpers() {
        List<Helper> helpers = DBConnector.getAllHelpers();
        if (helpers.isEmpty()) {
            System.out.println("No helpers found.");
        } else {
            for (Helper h : helpers) {
                System.out.println("Name: " + h.getName() + ", Role: " + h.getRole() + ", Aadhar: " + h.getAadharNumber() + ", Contact: " + h.getContactInfo() + ", Salary: " + h.getSalary());
            }
        }
    }
}
