package cli;

import Management.*;
import java.util.List;
import java.util.Scanner;
import exceptions.*;

public class AdminCLI {
    private ResidentManager residentManager;
    private HelperManager helperManager;
    private MaintenanceManager maintenanceManager;
    private NoticeManager noticeManager;
    private ApartmentManager apartmentManager;
    private ComplaintManager complaintManager;
    private CommitteeManager committeeManager;
    private VehicleManager vehicleManager;
    private Scanner scanner;

    public AdminCLI() {
        residentManager = new ResidentManager();
        helperManager = new HelperManager();
        maintenanceManager = new MaintenanceManager();
        noticeManager = new NoticeManager();
        apartmentManager = new ApartmentManager();
        complaintManager = new ComplaintManager();
        committeeManager = new CommitteeManager();
        vehicleManager = new VehicleManager();
        scanner = new Scanner(System.in);
    }

    public void showAdminMenu() {
        while (true) {
            System.out.println("\n===== Admin Panel =====");
            System.out.println("1. Apartment Menu");
            System.out.println("2. Helpers Menu");
            System.out.println("3. Maintenance Menu");
            System.out.println("4. Notices Menu");
            System.out.println("5. Residents Menu");
            System.out.println("6. Complaint Menu");
            System.out.println("7. Committee Menu");
            System.out.println("8. Vehicles Menu");
            System.out.println("0. Logout");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    apartmentMenu();
                    break;
                case 2:
                    helperMenu();
                    break;
                case 3:
                    maintenanceMenu();
                    break;
                case 4:
//                    noticeMenu();
                    break;
                case 5:
                    residentsMenu();
                    break;
                case 6:
                    complaintMenu();
                    break;
                case 7:
                    committeeMenu();
                    break;
                case 8:
                    vehicleMenu();
                    break;
                case 0:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }

    public void residentsMenu() {
        while (true) {
            System.out.println("\n--- Manage Residents ---");
            System.out.println("1. Update Resident");
            System.out.println("2. Remove Resident");
            System.out.println("3. View All Residents");
            System.out.println("0. Back to Admin Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    updateResident();
                    break;
                case 2:
                    removeResident();
                    break;
                case 3:
                    residentManager.viewAllResidents();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }

    private void updateResident() {
                    //Apartment Number Block        
                    String apartmentNumber=null;
                    boolean isValidAprtNum = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Apartment Number : ");
                            apartmentNumber = scanner.nextLine();

                            if (!apartmentNumber.matches("^(10[1-4]|20[1-4]|30[1-4]|40[1-4]|50[1-4])$")) 
                            {
                                throw new ApartmentNumberException();
                            }

                            isValidAprtNum = true;

                        } 
                        catch (ApartmentNumberException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    } 
                    while (!isValidAprtNum);
                    
                    
                    //Name Block 
                    String name=null;
                    boolean isValidname = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Updated Name : ");
                            name = scanner.nextLine();
                            if (!name.matches("[A-Za-z ]+")) 
                            {
                                throw new rName();
                            }
                            isValidname = true;
                        } 
                        catch (rName use) 
                        {
                            System.out.println("Error:" + use.getMessage());
                        }
                    } 
                    while (!isValidname);
                    
                    
                    //Contact Block        
                    String contact=null;
                    boolean isValidContact = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Updated Contact Number : ");
                            contact = scanner.nextLine();

                            if (!contact.matches("^\\d{10}$")) 
                            {
                                throw new ContactNumberException();
                            }

                            isValidContact = true;

                        } 
                        catch (ContactNumberException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    }    
                    while (!isValidContact);
                    
                    
                    String email=null;
                    boolean isValidEmail = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Updated Email : ");
                            email = scanner.nextLine();

                            if (!email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) 
                            {
                                throw new emailException();
                            }

                            isValidEmail = true;

                        } 
                        catch (emailException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    }    
                    while (!isValidEmail);
                    
        //Type Block 
                    String type=null;
                    boolean isValidtype = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Updated Type (Owner/Tenant) : ");
                            type = scanner.nextLine();
                            if (!type.matches("[A-Za-z ]+")) 
                            {
                                throw new OwnerTenantException();
                            }
                            isValidtype = true;
                        } 
                        catch (OwnerTenantException use) 
                        {
                            System.out.println("Error:" + use.getMessage());
                        }
                    } 
                    while (!isValidtype);

    ResidentManager.updateResident(apartmentNumber, type, name , contact, email);
    }


    private void removeResident() {
         //Apartment Number Block        
                    String apartmentNumber=null;
                    boolean isValidAprtNum = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Resident Apartment Number to Reamove : ");
                            apartmentNumber = scanner.nextLine();

                            if (!apartmentNumber.matches("^(10[1-4]|20[1-4]|30[1-4]|40[1-4]|50[1-4])$")) 
                            {
                                throw new ApartmentNumberException();
                            }

                            isValidAprtNum = true;

                        } 
                        catch (ApartmentNumberException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    } 
                    while (!isValidAprtNum);
        if (residentManager.removeResident(apartmentNumber)) {
            System.out.println("Resident removed successfully!");
        } else {
            System.out.println("Resident not found or could not be removed.");
        }
    }

    public void helperMenu() {
        while (true) {
            System.out.println("\nHelper Management:");
            System.out.println("1. Add Helper");
            System.out.println("2. Remove Helper");
            System.out.println("3. View Helpers");
            System.out.println("0. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addHelper();
                    break;
                case 2:
                    removeHelper();
                    break;
                case 3:
                    helperManager.viewHelpers();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private void addHelper() {
        //Name Block
        String name=null;
        boolean isValidname = false;
        do 
        {
            try 
            {
                System.out.print("Name : ");
                name = scanner.nextLine();
                if (!name.matches("[A-Za-z ]+")) 
                {
                    throw new rName();
                }
                isValidname = true;
            } 
            catch (rName use) 
            {
                System.out.println("Error:" + use.getMessage());
            }
        } 
        while (!isValidname);
        
        
        //Helpers Role Block
        String role = null;
        boolean isValidrole = false;
        do 
        {
            try 
            {
                System.out.print("Role: Maid|Gardner|Security|Sweeper|car washer : ");
                role = scanner.nextLine();
                if (!role.matches("(?i)^(Maid|Gardner|Security|Sweeper|car washer)$")) 
                {
                    throw new hRole();
                }
                isValidrole = true;
            } 
            catch (hRole use) 
            {
                System.out.println("Error:" + use.getMessage());
            }
        } 
        while (!isValidrole);
        
        
        //Salary Block
        double salary = 0;
        boolean isValidSalary = false;
        do 
        {
            System.out.print("Salary: ");
            String salaryInput = scanner.nextLine(); // Read input as a String
            if (salaryInput.matches("^\\d+(\\.\\d{1,2})?$")) { // Regex for positive number with optional decimals
                try 
                {
                    salary = Double.parseDouble(salaryInput); //Converting String data type to Double 
                    if (salary <= 0) 
                    {
                        throw new hSalary();
                    }
                    isValidSalary = true;
                } 
                catch (hSalary e) 
                {
                    System.out.println("Error: " + e.getMessage());
                }
            } 
            else 
            {
                System.out.println("Error: Invalid salary format. Please enter a positive number (e.g., 100 or 100.50).");
            }
        } 
        while (!isValidSalary);
        
        scanner.nextLine();
        String contactInfo=null;
        boolean isValidContact = false;
        do 
        {
            try 
            {
                System.out.print("Contact Number : ");
                contactInfo = scanner.nextLine();

                if (!contactInfo.matches("^\\d{10}$")) 
                {
                    throw new ContactNumberException();
                }
                isValidContact = true;
            } 
            catch (ContactNumberException e) 
            {
                System.out.println("Error: " + e.getMessage());
            }
        } 
        while (!isValidContact);
        
        System.out.print("Enter Aadhar Number: ");
        Long aadharNumber = Long.parseLong(scanner.nextLine());

        helperManager.addHelper(name, role, salary, contactInfo, aadharNumber);
        System.out.println("Helper added successfully!");
    }

    private void removeHelper() {
        System.out.print("Enter Helper Name to Remove: ");
        String name = scanner.nextLine();
        helperManager.removeHelper(name);
        System.out.println("Helper removed successfully!");
    }

    public void maintenanceMenu() {
        while (true) {
            System.out.println("\nMaintenance Management:");
            System.out.println("1. View Maintenance Records");
            System.out.println("0. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    maintenanceManager.viewMaintenanceRecords();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

//    public void noticeMenu() {
//        while (true) {
//            System.out.println("\nNotices Management:");
//            System.out.println("1. Issue Notice");
//            System.out.println("2. View Notices");
//            System.out.println("0. Go Back");
//            int choice = scanner.nextInt();
//            scanner.nextLine();
//
//            switch (choice) {
//                case 1:
//                    issueNotice();
//                    break;
//                case 2:
//                    noticeManager.viewNotices();
//                    break;
//                case 0:
//                    return;
//                default:
//                    System.out.println("Invalid choice! Please try again.");
//            }
//        }
//    }

//    private void issueNotice() {
//        System.out.print("Enter Notice Title: ");
//        String title = scanner.nextLine();
//        System.out.print("Enter Notice Content: ");
//        String content = scanner.nextLine();
//        System.out.print("IssuedBy : ");
//        int issuedBy = scanner.nextLine();
//        noticeManager.issueNotice(title, content, issuedBy);
//        System.out.println("Notice issued successfully!");
//    }

    public void apartmentMenu() {
        while (true) {
            System.out.println("\nApartment Management:");
            System.out.println("1. View All Apartments");
            System.out.println("2. Update Apartment");
            System.out.println("0. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    apartmentManager.viewAllApartments();
                    break;
                case 2:
                    //Apartment Number Block        
                    String apartmentNumber=null;
                    boolean isValidAprtNum = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Apartment Number : ");
                            apartmentNumber = scanner.nextLine();

                            if (!apartmentNumber.matches("^(10[1-4]|20[1-4]|30[1-4]|40[1-4]|50[1-4])$")) 
                            {
                                throw new ApartmentNumberException();
                            }

                            isValidAprtNum = true;

                        } 
                        catch (ApartmentNumberException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    } 
                    while (!isValidAprtNum);
                    
                    
                    //Name Block 
                    String name=null;
                    boolean isValidname = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Updated Name : ");
                            name = scanner.nextLine();
                            if (!name.matches("[A-Za-z ]+")) 
                            {
                                throw new rName();
                            }
                            isValidname = true;
                        } 
                        catch (rName use) 
                        {
                            System.out.println("Error:" + use.getMessage());
                        }
                    } 
                    while (!isValidname);
                    
                    
                    //Type Block 
                    String type=null;
                    boolean isValidtype = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Updated Type : ");
                            type = scanner.nextLine();
                            if (!type.matches("[A-Za-z ]+")) 
                            {
                                throw new OwnerTenantException();
                            }
                            isValidtype = true;
                        } 
                        catch (OwnerTenantException use) 
                        {
                            System.out.println("Error:" + use.getMessage());
                        }
                    } 
                    while (!isValidtype);
                    
                    //Contact Block        
                    String contact=null;
                    boolean isValidContact = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Updated Contact Number : ");
                            contact = scanner.nextLine();

                            if (!contact.matches("^\\d{10}$")) 
                            {
                                throw new ContactNumberException();
                            }

                            isValidContact = true;

                        } 
                        catch (ContactNumberException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    }    
                    while (!isValidContact);
                    
                    
                    String email=null;
                    boolean isValidEmail = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Updated Email : ");
                            email = scanner.nextLine();

                            if (!email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) 
                            {
                                throw new emailException();
                            }

                            isValidEmail = true;

                        } 
                        catch (emailException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    }    
                    while (!isValidEmail);

                    apartmentManager.updateApartment(apartmentNumber, name, type, contact, email);
                    System.out.println("Apartment Updated successfully!");
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    public void complaintMenu() {
        while (true) {
            System.out.println("\nComplaint Management:");
            System.out.println("1. View All Complaints");
            System.out.println("2. Resolve Complaint");
            System.out.println("0. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    complaintManager.viewAllComplaints();
                    break;
                case 2:
                    System.out.print("Enter Complaint ID to resolve: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    complaintManager.resolveComplaint(id);
                    System.out.println("Complaint resolved successfully!");
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    public void committeeMenu() {
        while (true) {
            System.out.println("\nCommittee Management:");
            System.out.println("1. Create Committee");
            System.out.println("2. View Committees");
            System.out.println("0. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Committee Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Committee Head: ");
                    String head = scanner.nextLine();
                    System.out.print("Enter members: ");
                    String Members = scanner.nextLine();
                    System.out.print("Enter Committee Description: ");
                    String description = scanner.nextLine();
                    committeeManager.createCommittee(name, head, Members, description);
                    System.out.println("Committee created successfully!");
                    break;
                case 2:
                    committeeManager.viewAllCommittees();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    public void vehicleMenu() {
        while (true) {
            System.out.println("\nVehicle Management:");
            System.out.println("1. Add Vehicle");
            System.out.println("2. Remove Vehicle");
            System.out.println("3. View All Vehicles");
            System.out.println("0. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Registration Number: ");
                    String regNo = scanner.nextLine();
                    System.out.print("Enter Your Name: ");
                    String name = scanner.nextLine();
                    
                    //Apartment Number Block        
                    String aptNo=null;
                    boolean isValidAprtNum = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Apartment Number : ");
                            aptNo = scanner.nextLine();

                            if (!aptNo.matches("^(10[1-4]|20[1-4]|30[1-4]|40[1-4]|50[1-4])$")) 
                            {
                                throw new ApartmentNumberException();
                            }

                            isValidAprtNum = true;

                        } 
                        catch (ApartmentNumberException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    } 
                    while (!isValidAprtNum);
                    System.out.print("Enter Owner Name: ");
                    String owner = scanner.nextLine();
                    System.out.print("Enter Type (2-Wheeler/4-Wheeler): ");
                    String type = scanner.nextLine();
                    vehicleManager.addVehicle(regNo, aptNo, owner, type);
                    System.out.println("Vehicle added successfully!");
                    break;
                case 2:
                    System.out.print("Enter Registration Number to Remove: ");
                    String removeRegNo = scanner.nextLine();
                    vehicleManager.removeVehicle(removeRegNo);
                    System.out.println("Vehicle removed successfully!");
                    break;
                case 3:
                    vehicleManager.viewAllVehicles();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}