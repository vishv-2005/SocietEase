package cli;

import storage.DBConnector;
import java.util.Scanner;

public class MainCLI {
    public static void main(String[] args) {
        // Initialize the database connection
        new DBConnector(); // This creates the SocietEase database and tables if they don't exist

        Scanner scanner = new Scanner(System.in);
        System.out.println("===== Welcome to SocietEase =====");

        while (true) {
            System.out.println("Select Mode:");
            System.out.println("1. Admin");
            System.out.println("2. User");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    AdminCLI adminCLI = new AdminCLI();
                    adminCLI.showAdminMenu(); // Calls Admin Menu
                    break;

                case 2:
                    UserCLI userCLI = new UserCLI(scanner); // Pass scanner as an argument
                    userCLI.start(); // Calls User Menu
                    break;

                case 0:
                    System.out.println("Exiting SocietEase. Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
