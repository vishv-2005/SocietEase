package cli;

import Management.*;
import exceptions.*;
import java.util.Scanner;

public class UserCLI {
    private MaintenanceManager maintenanceManager;
    private HelperManager helperManager;
    private NoticeManager noticeManager;
    private ApartmentManager apartmentManager;
    private ComplaintManager complaintManager;
    private CommitteeManager committeeManager;
    private VehicleManager vehicleManager;
    private Scanner scanner;

    public UserCLI(Scanner scanner) {
        maintenanceManager = new MaintenanceManager();
        helperManager = new HelperManager();
        noticeManager = new NoticeManager();
        apartmentManager = new ApartmentManager();
        complaintManager = new ComplaintManager();
        committeeManager = new CommitteeManager();
        vehicleManager = new VehicleManager();
        this.scanner = scanner;
    }

    public void start() {
        while (true) {
            System.out.println("\nUser Menu:");
            System.out.println("1. Maintenance Menu");
            System.out.println("2. Helper Menu");
            System.out.println("3. Notice Menu");
            System.out.println("4. Complaint Menu");
            System.out.println("5. View Committee Details");
            System.out.println("6. View Vehicles");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    maintenanceMenu();
                    break;
                case 2:
                    helperMenu();
                    break;
                case 3:
                    noticeMenu();
                    break;
                case 4:
                    fileComplaintMenu();
                    break;
                case 5:
                    viewCommitteeDetails();
                    break;
                case 6:
                    System.out.println("Enter Your Apartment Number:");
                    String apartmentNumber = scanner.nextLine();
                    viewUserVehicles(apartmentNumber);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
    }

    public void maintenanceMenu() {
        while (true) {
            System.out.println("\nMaintenance Payment:");
            System.out.println("1. Pay Maintenance");
            System.out.println("2. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    payMaintenance();
                    break;
                case 2:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private void payMaintenance() {
        System.out.print("Enter Your Name: ");
        String name = scanner.nextLine();
                    //Apartment Number Block        
                    String apartmentNumber=null;
                    boolean isValidAprtNum = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Apartment Number : ");
                            apartmentNumber = scanner.nextLine();

                            if (!apartmentNumber.matches("^(10[1-4]|20[1-4]|30[1-4]|40[1-4]|50[1-4])$")) 
                            {
                                throw new ApartmentNumberException();
                            }

                            isValidAprtNum = true;

                        } 
                        catch (ApartmentNumberException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    } 
                    while (!isValidAprtNum);
        System.out.print("Enter Amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();
        //Mode of Payment Block
        String mode = null;
        boolean isValidMode = false;
        do 
        {
            try 
            {
                System.out.print("Mode of Payment (Online/Cash/Cheque): ");
                mode= scanner.nextLine();
                if (!mode.matches("(?i)^(online|cash|cheque)$")) 
                {
                    throw new PmodeException();
                }
                isValidMode = true;
            } 
            catch (PmodeException use) 
            {
                System.out.println("Error:" + use.getMessage());
            }
        } 
        while (!isValidMode);
        System.out.print("Enter Contact Info: ");
        String contactInfo = scanner.nextLine();

        maintenanceManager.payMaintenance(name, apartmentNumber, amount, mode, contactInfo);
        System.out.println("Maintenance payment recorded successfully!");
    }

    public void helperMenu() {
        while (true) {
            System.out.println("\nHelper Information:");
            System.out.println("1. View Helpers");
            System.out.println("2. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    helperManager.viewHelpers();
                    break;
                case 2:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    public void noticeMenu() {
        while (true) {
            System.out.println("\nNotice Board:");
            System.out.println("1. View Notices");
            System.out.println("2. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    noticeManager.viewNotices();
                    break;
                case 2:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    public void viewApartmentMenu() {
        while (true) {
            System.out.println("\nApartment Menu:");
            System.out.println("1. View Apartment Details");
            System.out.println("2. Go Back");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Your Name: ");
        String name = scanner.nextLine();
                    //Apartment Number Block        
                    String apartmentNumber=null;
                    boolean isValidAprtNum = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Apartment Number : ");
                            apartmentNumber = scanner.nextLine();

                            if (!apartmentNumber.matches("^(10[1-4]|20[1-4]|30[1-4]|40[1-4]|50[1-4])$")) 
                            {
                                throw new ApartmentNumberException();
                            }

                            isValidAprtNum = true;

                        } 
                        catch (ApartmentNumberException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    } 
                    while (!isValidAprtNum);
                    apartmentManager.viewApartmentByNumber(apartmentNumber);
                    break;
                case 2:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    public void fileComplaintMenu() {
        System.out.print("Enter Your Name: ");
        String name = scanner.nextLine();
                    //Apartment Number Block        
                    String apartmentNumber=null;
                    boolean isValidAprtNum = false;
                    do 
                    {
                        try 
                        {
                            System.out.print("Enter Apartment Number : ");
                            apartmentNumber = scanner.nextLine();

                            if (!apartmentNumber.matches("^(10[1-4]|20[1-4]|30[1-4]|40[1-4]|50[1-4])$")) 
                            {
                                throw new ApartmentNumberException();
                            }

                            isValidAprtNum = true;

                        } 
                        catch (ApartmentNumberException e) 
                        {
                            System.out.println("Error: " + e.getMessage());
                        }
                    } 
                    while (!isValidAprtNum);
        System.out.print("Enter Complaint Description: ");
        String description = scanner.nextLine();

        complaintManager.fileComplaint(apartmentNumber, description);
        System.out.println("Complaint filed successfully!");
    }

    public void viewCommitteeDetails() {
        committeeManager.viewAllCommittees();
    }

    public void viewUserVehicles(String apartmentNumber) {
        vehicleManager.viewUserVehicles(apartmentNumber);
    }
}