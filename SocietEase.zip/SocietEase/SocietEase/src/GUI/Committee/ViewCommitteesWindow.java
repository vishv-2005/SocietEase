package GUI.Committee;

import GUI.UIUtils;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import storage.DBConnector;
import models.Committee;
import java.util.List;
import java.awt.*;

public class ViewCommitteesWindow {
    public ViewCommitteesWindow() {
        JFrame frame = new JFrame("SocietEase - View Committees");
        frame.setSize(800, 500);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("View Committees", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        String[] columns = {"Committee ID", "Name", "Description", "Head", "Apartment Number"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        UIUtils.styleTable(table);
        
        JScrollPane scrollPane = new JScrollPane(table);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Fetch data from DB and fill table
        List<Committee> committeeList = DBConnector.getAllCommittees();
        for (Committee comm : committeeList) {
            model.addRow(new Object[]{
            comm.getCommitteeID(),
            comm.getName(),
            comm.getDescription(),
            comm.getHead(),
            comm.getApartmentNumber()               
            });
        }
        
        mainPanel.add(tablePanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
        
//        JFrame frame = new JFrame("View Committee");
//        frame.setSize(600, 400);
//        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        frame.setLocationRelativeTo(null);
//        frame.setLayout(new BorderLayout());
//
//        String[] columns = {"Committee ID", "Name", "Description", "Head", "Apartment Number"};
//
//        DefaultTableModel model = new DefaultTableModel(columns, 0);
//        JTable table = new JTable(model);
//        JScrollPane scrollPane = new JScrollPane(table);
//
//        // Fetch data from DB and fill table
//        List<Committee> committeeList = DBConnector.getAllCommittees();
//        for (Committee comm : committeeList) {
//            model.addRow(new Object[]{
//            comm.getCommitteeID(),         // 🔹 Now visible in the table
//            comm.getName(),
//            comm.getDescription(),
//            comm.getHead(),
//            comm.getApartmentNumber()
//        });
//    }
//
//        
//        frame.add(scrollPane, BorderLayout.CENTER);
//        frame.setVisible(true);
    }
}
