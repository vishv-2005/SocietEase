package GUI.Committee;

import GUI.UIUtils;
import models.Committee;
import storage.DBConnector;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class RemoveCommitteeForm {
    public RemoveCommitteeForm() {
        JFrame frame = new JFrame("SocietEase - Remove Committee");
        frame.setSize(450, 300);
        UIUtils.styleFrame(frame);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        UIUtils.stylePanel(panel);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JLabel title = new JLabel("Remove Committee", SwingConstants.CENTER);
        UIUtils.styleLabel(title, true);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 30)));

        JComboBox<String> comboBox = new JComboBox<>();
        UIUtils.styleComboBox(comboBox);
        comboBox.setMaximumSize(new Dimension(250, 30));
        panel.add(comboBox);

        List<Committee> committees = DBConnector.getAllCommittees();
        for (Committee c : committees) {
            comboBox.addItem(c.getCommitteeID() + " - " + c.getName());
        }

        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JButton deleteButton = new JButton("Delete Selected Committee");
        UIUtils.styleButton(deleteButton);
        deleteButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(deleteButton);

        deleteButton.addActionListener((ActionEvent e) -> {
            String selected = (String) comboBox.getSelectedItem();
            if (selected == null) {
                JOptionPane.showMessageDialog(frame, "No committee selected!");
                return;
            }

            String committeeID = selected.split(" - ")[0];

            int confirm = JOptionPane.showConfirmDialog(frame,
                    "Are you sure you want to delete this committee?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                DBConnector.removeCommittee(committeeID);
                JOptionPane.showMessageDialog(frame, "✅ Committee removed successfully!");
                frame.dispose();
            }
        });

        frame.add(panel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
