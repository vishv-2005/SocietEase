package GUI.Committee;

import GUI.UIUtils;
import models.Resident;
import models.Committee;
import storage.DBConnector;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class CreateCommitteeForm {
    public CreateCommitteeForm() {
        JFrame frame = new JFrame("SocietEase - Create Committee");
        frame.setSize(600, 500);
        UIUtils.styleFrame(frame);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        UIUtils.stylePanel(mainPanel);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JLabel title = new JLabel("Create Committee", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        UIUtils.styleLabel(title, true);
        mainPanel.add(title);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        JPanel formPanel = new JPanel(new GridBagLayout());
        UIUtils.stylePanel(formPanel);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        // Fields
        JLabel nameLabel = new JLabel("Committee Name:");
        UIUtils.styleLabel(nameLabel, false);
        JTextField nameField = new JTextField(20);
        UIUtils.styleTextField(nameField);

        JLabel descLabel = new JLabel("Description:");
        UIUtils.styleLabel(descLabel, false);
        JTextField descField = new JTextField(20);
        UIUtils.styleTextField(descField);
        
        //Enter Facility
        nameField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                descField.requestFocus();
            }
        });

        JLabel headLabel = new JLabel("Select Head (Resident):");
        UIUtils.styleLabel(headLabel, false);
        JComboBox<Resident> headCombo = new JComboBox<>();
        UIUtils.styleComboBox(headCombo);

        JLabel aptLabel = new JLabel("Apartment Number:");
        UIUtils.styleLabel(aptLabel, false);
        JTextField aptField = new JTextField(20);
        aptField.setEditable(false);
        UIUtils.styleTextField(aptField);

        int row = 0;

        gbc.gridx = 0; gbc.gridy = row; formPanel.add(nameLabel, gbc);
        gbc.gridx = 1; formPanel.add(nameField, gbc); row++;
        gbc.gridx = 0; gbc.gridy = row; formPanel.add(descLabel, gbc);
        gbc.gridx = 1; formPanel.add(descField, gbc); row++;
        gbc.gridx = 0; gbc.gridy = row; formPanel.add(headLabel, gbc);
        gbc.gridx = 1; formPanel.add(headCombo, gbc); row++;
        gbc.gridx = 0; gbc.gridy = row; formPanel.add(aptLabel, gbc);
        gbc.gridx = 1; formPanel.add(aptField, gbc);

        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        JButton createBtn = new JButton("Create Committee");
        UIUtils.styleButton(createBtn);
        createBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(createBtn);

        // Load residents
        List<Resident> residents = DBConnector.getAllResidents();
        for (Resident r : residents) {
            headCombo.addItem(r);
        }

        headCombo.addActionListener(e -> {
            Resident selected = (Resident) headCombo.getSelectedItem();
            if (selected != null) {
                aptField.setText(selected.getApartmentNumber());
            }
        });

        createBtn.addActionListener((ActionEvent e) -> {
            String name = nameField.getText().trim();
            String desc = descField.getText().trim();
            Resident selectedHead = (Resident) headCombo.getSelectedItem();

            if (name.isEmpty() || desc.isEmpty() || selectedHead == null) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Committee committee = new Committee();
            committee.setName(name);
            committee.setDescription(desc);
            committee.setHead(selectedHead.getName());
            committee.setApartmentNumber(selectedHead.getApartmentNumber());

            DBConnector.addCommittee(committee);
            JOptionPane.showMessageDialog(frame, "✅ Committee created successfully!");

            nameField.setText("");
            descField.setText("");
            aptField.setText("");
        });

        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
