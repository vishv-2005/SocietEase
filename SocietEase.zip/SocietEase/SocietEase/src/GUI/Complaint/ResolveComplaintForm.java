package GUI.Complaint;

import GUI.UIUtils;
import models.Complaint;
import storage.DBConnector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ResolveComplaintForm {
    public ResolveComplaintForm() {
        JFrame frame = new JFrame("SocietEase - Resolve Complaint");
        frame.setSize(750, 400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        UIUtils.styleFrame(frame);
        frame.setLayout(new BorderLayout());

        String[] columns = {"Complaint ID", "Apartment", "Date", "Description"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        UIUtils.styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JButton resolveButton = new JButton("Resolve Selected Complaint");
        UIUtils.styleButton(resolveButton);

        JPanel buttonPanel = new JPanel();
        UIUtils.stylePanel(buttonPanel);
        buttonPanel.add(resolveButton);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        List<Complaint> complaints = DBConnector.getAllComplaints();
        for (Complaint c : complaints) {
            model.addRow(new Object[]{
                c.getComplaintID(),
                c.getApartmentNumber(),
                c.getDateFiled(),
                c.getDescription()
            });
        }

        resolveButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int complaintID = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
                DBConnector.resolveAndDeleteComplaint(complaintID);
                model.removeRow(selectedRow);
                JOptionPane.showMessageDialog(frame, "Complaint resolved and removed.");
                frame.dispose();
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a complaint to resolve.");
            }
        });

        frame.setVisible(true);
    }
}
