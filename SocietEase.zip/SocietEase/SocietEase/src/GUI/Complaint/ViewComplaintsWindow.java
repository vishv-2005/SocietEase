package GUI.Complaint;

import GUI.UIUtils;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import storage.DBConnector;
import models.Complaint;
import java.util.List;
import java.awt.*;

public class ViewComplaintsWindow {
    public ViewComplaintsWindow() {
        JFrame frame = new JFrame("SocietEase - View Complaints");
        frame.setSize(700, 400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        UIUtils.styleFrame(frame);
        frame.setLayout(new BorderLayout());

        String[] columns = {"Complaint ID", "Apartment Number", "Description", "Date"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        UIUtils.styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);

        List<Complaint> complaints = DBConnector.getAllComplaints();
        for (Complaint com : complaints) {
            model.addRow(new Object[]{
                com.getComplaintID(),
                com.getApartmentNumber(),
                com.getDescription(),
                com.getDateFiled()
            });
        }

        frame.add(scrollPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
