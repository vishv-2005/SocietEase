package GUI;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;

public class UIUtils {

    // Modern color scheme
    public static final Color PRIMARY_COLOR = new Color(63, 81, 181);  // Material Blue
    public static final Color SECONDARY_COLOR = new Color(33, 150, 243); // Light Blue
    public static final Color BACKGROUND_COLOR = new Color(250, 250, 250); // Light Gray
    public static final Color TEXT_COLOR = new Color(33, 33, 33); // Dark Gray
    public static final Color ACCENT_COLOR = new Color(233, 30, 99); // Pink
    public static final Color SUCCESS_COLOR = new Color(76, 175, 80); // Green
    public static final Color CARD_BACKGROUND = new Color(255, 255, 255); // White
    public static final Color BORDER_COLOR = new Color(224, 224, 224); // Light Gray Border

    // Modern fonts
    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font NORMAL_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font SMALL_FONT = new Font("Segoe UI", Font.PLAIN, 12);

    // Button styling with modern look
    public static void styleButton(JButton button) {
        button.setFont(BUTTON_FONT);
        button.setForeground(Color.WHITE);
        button.setBackground(PRIMARY_COLOR);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setMaximumSize(new Dimension(200, 40));

        // Add hover effect with smooth transition
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(SECONDARY_COLOR);
                button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(SECONDARY_COLOR, 1),
                    BorderFactory.createEmptyBorder(9, 19, 9, 19)
                ));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(PRIMARY_COLOR);
                button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
            }
        });
    }

    // Label styling with modern look
    public static void styleLabel(JLabel label, boolean isTitle) {
        label.setFont(isTitle ? TITLE_FONT : NORMAL_FONT);
        label.setForeground(TEXT_COLOR);
        if (isTitle) {
            label.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        }
    }

    // ComboBox styling with modern look
    public static void styleComboBox(JComboBox<?> comboBox) {
        comboBox.setFont(NORMAL_FONT);
        comboBox.setBackground(CARD_BACKGROUND);
        comboBox.setMaximumSize(new Dimension(250, 35));
        comboBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
    }

    // Text field styling with modern look
    public static void styleTextField(JTextField textField) {
        textField.setFont(NORMAL_FONT);
        textField.setForeground(TEXT_COLOR);
        textField.setBackground(CARD_BACKGROUND);
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        textField.setMaximumSize(new Dimension(300, 35));
    }

    // Table styling with modern look
    public static void styleTable(JTable table) {
        table.setFont(NORMAL_FONT);
        table.setRowHeight(35);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setSelectionBackground(SECONDARY_COLOR);
        table.setSelectionForeground(Color.WHITE);
        table.setBackground(CARD_BACKGROUND);
        table.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));

        // Style header
        table.getTableHeader().setFont(HEADER_FONT);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
    }

    // Frame styling with modern look
    public static void styleFrame(JFrame frame) {
        frame.getContentPane().setBackground(BACKGROUND_COLOR);
        frame.setIconImage(new ImageIcon("src/resources/icon.png").getImage());
    }

    // Panel styling with modern look
    public static void stylePanel(JPanel panel) {
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    }

    // Text area styling with modern look
    public static void styleTextArea(JTextArea area) {
        area.setFont(NORMAL_FONT);
        area.setForeground(TEXT_COLOR);
        area.setBackground(CARD_BACKGROUND);
        area.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
    }

    // Card panel styling
    public static void styleCardPanel(JPanel panel) {
        panel.setBackground(CARD_BACKGROUND);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
    }

    // Flow panel styling with modern look
    public static void styleFlowPanel(JPanel panel) {
        panel.setBackground(BACKGROUND_COLOR);
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 25, 15));
    }

    // Create a modern card panel
    public static JPanel createCardPanel() {
        JPanel card = new JPanel();
        styleCardPanel(card);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        return card;
    }

    // Create a modern section panel
    public static JPanel createSectionPanel(String title) {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setBackground(BACKGROUND_COLOR);
        
        JLabel titleLabel = new JLabel(title);
        styleLabel(titleLabel, true);
        section.add(titleLabel);
        section.add(Box.createRigidArea(new Dimension(0, 20)));
        
        return section;
    }
}
