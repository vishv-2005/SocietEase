package GUI.Apartment;

import GUI.UIUtils;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import models.Apartment;
import storage.DBConnector;
import java.awt.*;
import java.util.List;
import models.Notice;

public class ViewApartmentsWindow {
    public ViewApartmentsWindow() {
        JFrame frame = new JFrame("SocietEase - View Apartments");
        frame.setSize(800, 500);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("View Apartments", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        String[] columns = {"Apartment Number", "Name", "Type"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        UIUtils.styleTable(table);
        
        JScrollPane scrollPane = new JScrollPane(table);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Fetch data from DB and fill table
        List<Apartment> apartmentList = DBConnector.getAllApartments();
        for (Apartment apt : apartmentList) {
            model.addRow(new Object[]{
                apt.getApartmentNumber(),
                apt.getName(),
                apt.getType(),                
            });
        }
        
        mainPanel.add(tablePanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
