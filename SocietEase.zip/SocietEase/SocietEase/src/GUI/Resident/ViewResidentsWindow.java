package GUI.Resident;

import GUI.UIUtils;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import storage.DBConnector;
import models.Resident;
import java.util.List;
import java.awt.*;

public class ViewResidentsWindow {
    public ViewResidentsWindow() {
        JFrame frame = new JFrame("SocietEase - View Residents");
        frame.setSize(1000, 600);
        UIUtils.styleFrame(frame);
        
        // Main panel with modern layout
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Header section
        JPanel headerPanel = UIUtils.createSectionPanel("Resident Directory");
        headerPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(headerPanel);
        
        // Search panel
        JPanel searchPanel = UIUtils.createCardPanel();
        searchPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        searchPanel.setMaximumSize(new Dimension(800, 60));
        
        JTextField searchField = new JTextField();
        UIUtils.styleTextField(searchField);
        searchField.setPreferredSize(new Dimension(300, 35));
        
        JButton searchButton = new JButton("Search");
        UIUtils.styleButton(searchButton);
        
        searchPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        searchPanel.add(new JLabel("Search: "));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        mainPanel.add(searchPanel);
        
        // Table panel with modern styling
        JPanel tablePanel = UIUtils.createCardPanel();
        tablePanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        tablePanel.setMaximumSize(new Dimension(800, 400));
        
        String[] columns = {"Apartment Number", "Name", "Contact", "E-Mail"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable table = new JTable(model);
        UIUtils.styleTable(table);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        tablePanel.add(scrollPane);
        
        // Fetch data from DB and fill table
        List<Resident> residentList = DBConnector.getAllResidents();
        for (Resident resident : residentList) {
            model.addRow(new Object[]{
                resident.getApartmentNumber(),
                resident.getName(),
                resident.getContactInfo(),
                resident.getEmail()
            });
        }
        
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        mainPanel.add(tablePanel);
        
        // Action buttons panel
        JPanel actionPanel = new JPanel();
        actionPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        actionPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        actionPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JButton refreshButton = new JButton("Refresh");
        JButton closeButton = new JButton("Close");
        
        UIUtils.styleButton(refreshButton);
        UIUtils.styleButton(closeButton);
        
        actionPanel.add(refreshButton);
        actionPanel.add(closeButton);
        
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        mainPanel.add(actionPanel);
        
        // Add action listeners
        closeButton.addActionListener(e -> frame.dispose());
        refreshButton.addActionListener(e -> {
            model.setRowCount(0);
            List<Resident> updatedList = DBConnector.getAllResidents();
            for (Resident resident : updatedList) {
                model.addRow(new Object[]{
                    resident.getApartmentNumber(),
                    resident.getName(),
                    resident.getContactInfo(),
                    resident.getEmail()
                });
            }
        });
        
        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
