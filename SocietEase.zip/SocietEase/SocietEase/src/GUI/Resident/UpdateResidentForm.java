package GUI.Resident;

import GUI.UIUtils;
import models.Resident;
import storage.DBConnector;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import models.Apartment;

public class UpdateResidentForm {

    public UpdateResidentForm() {
        JFrame frame = new JFrame("SocietEase - Update Resident");
        frame.setSize(600, 550);
        UIUtils.styleFrame(frame);

        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);

        // Title
        JLabel titleLabel = new JLabel("Update Resident", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Apartment Number (ComboBox)
        JLabel aptLabel = new JLabel("Apartment Number:");
        UIUtils.styleLabel(aptLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(aptLabel, gbc);

        JComboBox<String> aptComboBox = new JComboBox<>();
        UIUtils.styleComboBox(aptComboBox);
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(aptComboBox, gbc);

        // Populate combo box with apartment numbers from DB
        List<Apartment> apartmentList = DBConnector.getAllApartments();
        for (Apartment apt : apartmentList) {
            aptComboBox.addItem(apt.getApartmentNumber());
        }

        // Name field
        JLabel nameLabel = new JLabel("Name:");
        UIUtils.styleLabel(nameLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(nameLabel, gbc);

        JTextField nameField = new JTextField(20);
        UIUtils.styleTextField(nameField);
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(nameField, gbc);

        // Contact field
        JLabel contactLabel = new JLabel("Contact:");
        UIUtils.styleLabel(contactLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(contactLabel, gbc);

        JTextField contactField = new JTextField(20);
        UIUtils.styleTextField(contactField);
        gbc.gridx = 1;
        gbc.gridy = 2;
        formPanel.add(contactField, gbc);
        
        //Enter Facility
        nameField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                contactField.requestFocus();
            }
        });

        // Email field
        JLabel emailLabel = new JLabel("Email:");
        UIUtils.styleLabel(emailLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(emailLabel, gbc);

        JTextField emailField = new JTextField(20);
        UIUtils.styleTextField(emailField);
        gbc.gridx = 1;
        gbc.gridy = 3;
        formPanel.add(emailField, gbc);
        
        //Enter Facility
        contactField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                emailField.requestFocus();
            }
        });

        JLabel modeLabel = new JLabel("Resident Type");
        UIUtils.styleLabel(modeLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(modeLabel, gbc);

        String[] Types = {"Owner", "Tenant"};
        JComboBox<String> typeCombo = new JComboBox<>(Types);
        typeCombo.setFont(UIUtils.NORMAL_FONT);
        gbc.gridx = 1;
        gbc.gridy = 4;
        formPanel.add(typeCombo, gbc);

        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Update button
        JButton updateButton = new JButton("Update Resident");
        UIUtils.styleButton(updateButton);
        updateButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        updateButton.addActionListener(e -> {
            String aptNo = (String) aptComboBox.getSelectedItem();
            String name = nameField.getText();
            String contact = contactField.getText();
            String email = emailField.getText();
            String type = (String) typeCombo.getSelectedItem();

            if (name.isEmpty() || contact.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(frame,
                        "Please fill all fields.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                DBConnector.updateResident(aptNo, name, contact, email, type);

                JOptionPane.showMessageDialog(frame,
                        "Resident updated successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);

                // Clear fields
                nameField.setText("");
                contactField.setText("");
                emailField.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame,
                        "Error: " + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        mainPanel.add(updateButton);

        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
