package GUI.Resident;

import GUI.UIUtils;
import models.Resident;
import storage.DBConnector;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class RemoveResidentForm {
    public RemoveResidentForm() {
        JFrame frame = new JFrame("SocietEase - Remove Resident");
        frame.setSize(500, 300);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("Remove Resident", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Select resident
        JLabel selectLabel = new JLabel("Select Resident:");
        UIUtils.styleLabel(selectLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(selectLabel, gbc);
        
        JComboBox<String> residentCombo = new JComboBox<>();
        residentCombo.setFont(UIUtils.NORMAL_FONT);
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(residentCombo, gbc);
        
        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Load residents into combo box
        List<Resident> residents = DBConnector.getAllResidents();
        for (Resident resident : residents) {
            residentCombo.addItem(resident.getApartmentNumber() + " - " + resident.getName());
        }
        
        // Remove button
        JButton removeButton = new JButton("Remove Resident");
        UIUtils.styleButton(removeButton);
        removeButton.setBackground(UIUtils.ACCENT_COLOR);
        removeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        removeButton.addActionListener(e -> {
            String selected = (String) residentCombo.getSelectedItem();
            if (selected == null) {
                JOptionPane.showMessageDialog(frame, 
                    "Please select a resident to remove.", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int confirm = JOptionPane.showConfirmDialog(frame,
                "Are you sure you want to remove this resident?",
                "Confirm Removal",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
                
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    String apartmentNumber = selected.split(" - ")[0];
                    DBConnector.removeResident(apartmentNumber);
                    
                    JOptionPane.showMessageDialog(frame, 
                        "Resident removed successfully!", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    frame.dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, 
                        "Error: " + ex.getMessage(), 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
        
        mainPanel.add(removeButton);
        
        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
