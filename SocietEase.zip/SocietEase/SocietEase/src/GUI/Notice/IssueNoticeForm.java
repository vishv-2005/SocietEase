package GUI.Notice;

import GUI.UIUtils;
import models.Committee;
import models.Notice;
import storage.DBConnector;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class IssueNoticeForm {

    public IssueNoticeForm() {
        JFrame frame = new JFrame("SocietEase - Issue Notice");
        frame.setSize(600, 500);
        UIUtils.styleFrame(frame);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        UIUtils.stylePanel(mainPanel);

        JLabel titleLabel = new JLabel("Issue Notice");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        UIUtils.styleLabel(titleLabel, true);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        JPanel formPanel = new JPanel(new GridBagLayout());
        UIUtils.stylePanel(formPanel);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 10, 12, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Date
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        UIUtils.styleLabel(dateLabel, false);
        formPanel.add(dateLabel, gbc);

        gbc.gridx = 1;
        JTextField dateField = new JTextField(LocalDate.now().toString());
        UIUtils.styleTextField(dateField);
        formPanel.add(dateField, gbc);

        // Title
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel noticeTitleLabel = new JLabel("Notice Title:");
        UIUtils.styleLabel(noticeTitleLabel, false);
        formPanel.add(noticeTitleLabel, gbc);

        gbc.gridx = 1;
        JTextField titleField = new JTextField();
        UIUtils.styleTextField(titleField);
        formPanel.add(titleField, gbc);

        // Content
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel contentLabel = new JLabel("Content:");
        UIUtils.styleLabel(contentLabel, false);
        formPanel.add(contentLabel, gbc);

        gbc.gridx = 1;
        JTextArea contentArea = new JTextArea(5, 20);
        UIUtils.styleTextArea(contentArea);
        JScrollPane contentScroll = new JScrollPane(contentArea);
        contentScroll.setPreferredSize(new Dimension(300, 100));
        formPanel.add(contentScroll, gbc);

        // Committee dropdown
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel issuedByLabel = new JLabel("Issued By (Committee):");
        UIUtils.styleLabel(issuedByLabel, false);
        formPanel.add(issuedByLabel, gbc);

        gbc.gridx = 1;
        JComboBox<String> issuedByCombo = new JComboBox<>();
        UIUtils.styleComboBox(issuedByCombo);
        formPanel.add(issuedByCombo, gbc);

        // Load committees into dropdown
        List<Committee> committees = DBConnector.getAllCommittees();
        for (Committee c : committees) {
            issuedByCombo.addItem(c.getCommitteeID() + " - " + c.getName());
        }

        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Submit Button
        JButton submitButton = new JButton("Submit Notice");
        UIUtils.styleButton(submitButton);
        submitButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        submitButton.addActionListener(e -> {
            try {
                String date = dateField.getText().trim();
                String title = titleField.getText().trim();
                String content = contentArea.getText().trim();
                String issuedByItem = (String) issuedByCombo.getSelectedItem();

                if (issuedByItem == null || issuedByItem.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please select a committee.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int issuedBy = Integer.parseInt(issuedByItem.split(" - ")[0]);

                if (date.isEmpty() || title.isEmpty() || content.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Notice notice = new Notice();
                notice.setDate(LocalDate.parse(date));
                notice.setTitle(title);
                notice.setContent(content);
                notice.setIssuedBy(issuedBy);

                boolean success = DBConnector.addNotice(notice);

                if (success) {
                    JOptionPane.showMessageDialog(frame, "✅ Notice issued successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    titleField.setText("");
                    contentArea.setText("");
                    issuedByCombo.setSelectedIndex(0);
                } else {
                    JOptionPane.showMessageDialog(frame, "Error issuing notice. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        mainPanel.add(submitButton);
        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
