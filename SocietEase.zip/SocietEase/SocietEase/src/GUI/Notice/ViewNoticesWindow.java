package GUI.Notice;

import GUI.UIUtils;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import storage.DBConnector;
import models.Notice;
import java.util.List;
import java.awt.*;

public class ViewNoticesWindow {
    public ViewNoticesWindow() {
        JFrame frame = new JFrame("SocietEase - View Notices");
        frame.setSize(800, 500);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("View Notices", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        String[] columns = {"Notice ID", "Date", "Title", "Content", "Issued By"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        UIUtils.styleTable(table);
        
        JScrollPane scrollPane = new JScrollPane(table);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Fetch data from DB and fill table
        List<Notice> noticeList = DBConnector.getAllNotices();
        for (Notice notice : noticeList) {
            model.addRow(new Object[]{
                notice.getNoticeID(),
                notice.getDate(),
                notice.getTitle(),
                notice.getContent(),
                notice.getIssuedBy()
            });
        }
        
        mainPanel.add(tablePanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
