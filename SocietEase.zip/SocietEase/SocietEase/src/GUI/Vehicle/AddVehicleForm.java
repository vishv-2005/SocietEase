package GUI.Vehicle;

import GUI.UIUtils;
import models.Resident;
import models.Vehicle;
import storage.DBConnector;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class AddVehicleForm {
    public AddVehicleForm() {
        JFrame frame = new JFrame("SocietEase - Add Vehicle");
        frame.setSize(500, 500);
        UIUtils.styleFrame(frame);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        UIUtils.stylePanel(mainPanel);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JLabel titleLabel = new JLabel("Add New Vehicle", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        JPanel formPanel = new JPanel(new GridBagLayout());
        UIUtils.stylePanel(formPanel);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        // Form Fields
        JTextField regField = new JTextField();
        UIUtils.styleTextField(regField);

        JTextField typeField = new JTextField();
        UIUtils.styleTextField(typeField);
        
        //Enter Facility
        regField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                typeField.requestFocus();
            }
        });

        JComboBox<Resident> ownerCombo = new JComboBox<>();
        UIUtils.styleComboBox(ownerCombo);

        JTextField aptField = new JTextField();
        UIUtils.styleTextField(aptField);
        aptField.setEditable(false);

        // Load residents into combo box
        List<Resident> residents = DBConnector.getAllResidents();
        for (Resident res : residents) {
            ownerCombo.addItem(res);
        }

        // On resident selection -> autofill apartment
        ownerCombo.addActionListener(e -> {
            Resident selected = (Resident) ownerCombo.getSelectedItem();
            if (selected != null) {
                aptField.setText(selected.getApartmentNumber());
            }
        });

        // Labels
        JLabel regLabel = new JLabel("Registration No:");
        UIUtils.styleLabel(regLabel, false);

        JLabel typeLabel = new JLabel("Type (Car/Bike/Scooty):");
        UIUtils.styleLabel(typeLabel, false);

        JLabel ownerLabel = new JLabel("Owner Name:");
        UIUtils.styleLabel(ownerLabel, false);

        JLabel aptLabel = new JLabel("Apartment No:");
        UIUtils.styleLabel(aptLabel, false);

        // Add components to form
        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; formPanel.add(regLabel, gbc);
        gbc.gridx = 1; formPanel.add(regField, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row; formPanel.add(typeLabel, gbc);
        gbc.gridx = 1; formPanel.add(typeField, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row; formPanel.add(ownerLabel, gbc);
        gbc.gridx = 1; formPanel.add(ownerCombo, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row; formPanel.add(aptLabel, gbc);
        gbc.gridx = 1; formPanel.add(aptField, gbc);

        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Submit Button
        JButton addButton = new JButton("Add Vehicle");
        UIUtils.styleButton(addButton);
        addButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        addButton.addActionListener(e -> {
            String reg = regField.getText().trim();
            String type = typeField.getText().trim();
            Resident selected = (Resident) ownerCombo.getSelectedItem();

            if (reg.isEmpty() || type.isEmpty() || selected == null) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String owner = selected.getName();
            String apt = selected.getApartmentNumber();

            Vehicle v = new Vehicle(reg, apt, owner, type);
            DBConnector.addVehicle(v);
            JOptionPane.showMessageDialog(frame, "✅ Vehicle added successfully!");
            frame.dispose();
        });

        mainPanel.add(addButton);
        frame.add(mainPanel);
        frame.setVisible(true);
    }
}
