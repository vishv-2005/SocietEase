package GUI.Vehicle;

import GUI.UIUtils;
import models.Vehicle;
import models.Apartment;
import storage.DBConnector;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ViewUserVehiclesWindow {
    public ViewUserVehiclesWindow() {
        JFrame frame = new JFrame("SocietEase - View Vehicles by Apartment");
        frame.setSize(700, 500);
        UIUtils.styleFrame(frame);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        UIUtils.stylePanel(mainPanel);

        // Top panel with label, combo box and button
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        UIUtils.stylePanel(topPanel);

        JLabel selectLabel = new JLabel("Select Apartment:");
        UIUtils.styleLabel(selectLabel, false);

        JComboBox<String> apartmentCombo = new JComboBox<>();
        UIUtils.styleComboBox(apartmentCombo);

        JButton viewButton = new JButton("View Vehicles");
        UIUtils.styleButton(viewButton);

        topPanel.add(selectLabel);
        topPanel.add(apartmentCombo);
        topPanel.add(viewButton);

        // Table setup
        String[] columns = {"Registration No", "Owner", "Type"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        UIUtils.styleTable(table);
        JScrollPane scrollPane = new JScrollPane(table);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        frame.add(mainPanel);

        // Load apartment numbers
        List<Apartment> apartments = DBConnector.getAllApartments();
        for (Apartment apt : apartments) {
            apartmentCombo.addItem(apt.getApartmentNumber());
        }

        // Button action
        viewButton.addActionListener(e -> {
            String selectedApartment = (String) apartmentCombo.getSelectedItem();
            if (selectedApartment == null) return;

            List<Vehicle> vehicles = DBConnector.getUserVehicles(selectedApartment);
            model.setRowCount(0); // Clear table

            if (vehicles.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "No vehicles found for apartment " + selectedApartment);
            } else {
                for (Vehicle v : vehicles) {
                    model.addRow(new Object[]{
                            v.getRegistrationNumber(),
                            v.getOwnerName(),
                            v.getType()
                    });
                }
            }
        });

        frame.setVisible(true);
    }
}
