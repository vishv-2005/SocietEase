package GUI.Vehicle;

import GUI.UIUtils;
import storage.DBConnector;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RemoveVehicleForm {
    public RemoveVehicleForm() {
        JFrame frame = new JFrame("SocietEase - Remove Vehicle");
        frame.setSize(400, 350);
        UIUtils.styleFrame(frame);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        UIUtils.stylePanel(panel);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        JLabel titleLabel = new JLabel("Remove Vehicle");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        UIUtils.styleLabel(titleLabel, true);
        panel.add(titleLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 30)));

        JPanel formPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        UIUtils.stylePanel(formPanel);

        JLabel regLabel = new JLabel("Registration No:");
        UIUtils.styleLabel(regLabel, false);

        JTextField regField = new JTextField(15);
        UIUtils.styleTextField(regField);

        formPanel.add(regLabel);
        formPanel.add(regField);

        panel.add(formPanel);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JButton removeButton = new JButton("Remove Vehicle");
        UIUtils.styleButton(removeButton);
        removeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(removeButton);
        
        //Enter Facility
        regField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeButton.doClick();
            }
        });

        removeButton.addActionListener(e -> {
            String reg = regField.getText().trim();
            if (reg.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Enter registration number.");
                return;
            }

            DBConnector.removeVehicle(reg);
            JOptionPane.showMessageDialog(frame, "✅ Vehicle removed successfully!");
            frame.dispose();
        });

        frame.add(panel);
        frame.setVisible(true);
    }
}
