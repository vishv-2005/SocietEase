package GUI.ADMIN;

import GUI.Committee.*;
import GUI.UIUtils;
import javax.swing.*;
import java.awt.*;

public class CommitteeManagementWindow {
    public CommitteeManagementWindow() {
        JFrame frame = new JFrame("SocietEase - Committee Management");
        frame.setSize(500, 400);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("Committee Management", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Buttons panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        JButton createCommitteeButton = new JButton("Create Committee");
        UIUtils.styleButton(createCommitteeButton);
        createCommitteeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        createCommitteeButton.addActionListener(e -> new CreateCommitteeForm());
        
        JButton removeCommitteeButton = new JButton("Dissolve Committee");
        UIUtils.styleButton(removeCommitteeButton);
        removeCommitteeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        removeCommitteeButton.addActionListener(e -> new RemoveCommitteeForm());
        
        JButton viewCommitteesButton = new JButton("View Committees");
        UIUtils.styleButton(viewCommitteesButton);
        viewCommitteesButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewCommitteesButton.addActionListener(e -> new ViewCommitteesWindow());
        
        buttonPanel.add(createCommitteeButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(removeCommitteeButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(viewCommitteesButton);
        
        mainPanel.add(buttonPanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.dispose();
        frame.setVisible(true);
    }
}
