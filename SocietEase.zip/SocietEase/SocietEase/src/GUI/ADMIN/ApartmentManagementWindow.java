package GUI.ADMIN;

import GUI.Apartment.*;
import GUI.UIUtils;
import javax.swing.*;
import java.awt.*;

public class ApartmentManagementWindow {
    public ApartmentManagementWindow() {
        JFrame frame = new JFrame("SocietEase - Apartment Management");
        frame.setSize(500, 300);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("Apartment Management", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Buttons panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        JButton updateApartmentButton = new JButton("Update Apartment");
        UIUtils.styleButton(updateApartmentButton);
        updateApartmentButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        updateApartmentButton.addActionListener(e -> new UpdateApartmentForm());
        
        JButton viewApartmentsButton = new JButton("View Apartments");
        UIUtils.styleButton(viewApartmentsButton);
        viewApartmentsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewApartmentsButton.addActionListener(e -> new ViewApartmentsWindow());
        
        
        
        buttonPanel.add(updateApartmentButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(viewApartmentsButton);
        
        mainPanel.add(buttonPanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
