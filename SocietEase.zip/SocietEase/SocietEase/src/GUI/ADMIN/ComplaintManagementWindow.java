package GUI.ADMIN;

import GUI.Complaint.*;
import GUI.UIUtils;
import javax.swing.*;
import java.awt.*;

public class ComplaintManagementWindow {
    public ComplaintManagementWindow() {
        JFrame frame = new JFrame("SocietEase - Complaint Management");
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        UIUtils.styleFrame(frame);
        frame.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        UIUtils.stylePanel(panel);

        JLabel titleLabel = new JLabel("Complaint Management");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        UIUtils.styleLabel(titleLabel, true);

        JButton viewButton = new JButton("View Complaints");
        JButton resolveButton = new JButton("Resolve Complaint");
        UIUtils.styleButton(viewButton);
        UIUtils.styleButton(resolveButton);

        viewButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        resolveButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(Box.createVerticalStrut(20));
        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(20));
        panel.add(resolveButton);
        panel.add(Box.createVerticalStrut(20));
        panel.add(viewButton);
        

        frame.add(panel);
        viewButton.addActionListener(e -> new ViewComplaintsWindow());
        resolveButton.addActionListener(e -> new ResolveComplaintForm());

        frame.setVisible(true);
    }
}
