package GUI.ADMIN;

import GUI.Notice.*;
import GUI.UIUtils;
import javax.swing.*;
import java.awt.*;

public class NoticeManagementWindow {
    public NoticeManagementWindow() {
        JFrame frame = new JFrame("SocietEase - Notice Management");
        frame.setSize(500, 300);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("Notice Management", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Buttons panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        JButton issueNoticeButton = new JButton("Issue Notice");
        UIUtils.styleButton(issueNoticeButton);
        issueNoticeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        issueNoticeButton.addActionListener(e -> openIssueNoticesForm());
        
        JButton viewNoticesButton = new JButton("View Notices");
        UIUtils.styleButton(viewNoticesButton);
        viewNoticesButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewNoticesButton.addActionListener(e -> openViewNoticesWindow());
        
        buttonPanel.add(issueNoticeButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(viewNoticesButton);
        
        mainPanel.add(buttonPanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
    
    private void openIssueNoticesForm() {
        new IssueNoticeForm();
    }
    
    private void openViewNoticesWindow() {
        new ViewNoticesWindow();
    }
}
