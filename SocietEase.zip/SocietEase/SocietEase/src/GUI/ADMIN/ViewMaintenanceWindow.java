package GUI.ADMIN;

import GUI.UIUtils;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import storage.DBConnector;
import models.Maintenance;
import java.util.List;
import java.awt.*;
import models.Notice;

public class ViewMaintenanceWindow {
    public ViewMaintenanceWindow() {
       JFrame frame = new JFrame("SocietEase - View Maintenance");
        frame.setSize(800, 500);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("View Maintenance", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        String[] columns = {"Maintenance ID", "Name", "Apartment Number", "Contact Info", "Amount Paid","Mode Of Payment", "Payment Date"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        UIUtils.styleTable(table);
        
        JScrollPane scrollPane = new JScrollPane(table);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Fetch data from DB and fill table
        List<Maintenance> maintenanceList = DBConnector.getAllMaintenanceRecords();
        for (Maintenance mntnc : maintenanceList) {
            model.addRow(new Object[]{
                mntnc.getmaintenanceID(),
                mntnc.getName(),
                mntnc.getApartmentNumber(),
                mntnc.getContactInfo(),
                mntnc.getAmountPaid(),
                mntnc.getModeOfPayment(),
                mntnc.getPaymentDate(),
            });
        }
        
        mainPanel.add(tablePanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
