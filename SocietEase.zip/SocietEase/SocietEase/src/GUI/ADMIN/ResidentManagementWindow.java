package GUI.ADMIN;

import GUI.Resident.*;
import GUI.UIUtils;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;

public class ResidentManagementWindow {
    private JFrame frame;
    
    public ResidentManagementWindow() {
        frame = new JFrame("SocietEase - Resident Management");
        frame.setSize(800, 400);
        UIUtils.styleFrame(frame);
        
        // Main panel with modern layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        // Header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        
        // Action cards panel
        JPanel actionCardsPanel = createActionCardsPanel();
        contentPanel.add(actionCardsPanel);
        
        // Add content panel to main panel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.setBackground(UIUtils.BACKGROUND_COLOR);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UIUtils.PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(0, 80));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
        
        // Title
        JLabel titleLabel = new JLabel("Resident Management");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        // Back button
        JButton backButton = new JButton("Back to Dashboard");
        backButton.setFont(UIUtils.NORMAL_FONT);
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(UIUtils.ACCENT_COLOR);
        backButton.setFocusPainted(false);
        backButton.setBorderPainted(false);
        backButton.addActionListener(e -> frame.dispose());
        headerPanel.add(backButton, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    private JPanel createActionCardsPanel() {
        JPanel actionCardsPanel = new JPanel(new GridLayout(1, 3, 20, 0));
        actionCardsPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        // Create action cards
        String[] actions = {
            "Update Resident",
            "Remove Resident",
            "View Residents"
        };
        
        for (String action : actions) {
            JPanel actionCard = UIUtils.createCardPanel();
            actionCard.setLayout(new BoxLayout(actionCard, BoxLayout.Y_AXIS));
            
            JLabel titleLabel = new JLabel(action);
            titleLabel.setFont(UIUtils.HEADER_FONT);
            titleLabel.setForeground(UIUtils.TEXT_COLOR);
            titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            
            JButton actionButton = new JButton("Open");
            UIUtils.styleButton(actionButton);
            actionButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            
            // Add action listener based on text
            actionButton.addActionListener(e -> {
                switch(action) {
                    case "Update Resident": new UpdateResidentForm(); break;
                    case "Remove Resident": new RemoveResidentForm(); break;
                    case "View Residents": new ViewResidentsWindow(); break;
                }
            });
            
            actionCard.add(Box.createRigidArea(new Dimension(0, 20)));
            actionCard.add(titleLabel);
            actionCard.add(Box.createRigidArea(new Dimension(0, 20)));
            actionCard.add(actionButton);
            actionCard.add(Box.createRigidArea(new Dimension(0, 20)));
            
            actionCardsPanel.add(actionCard);
        }
        
        return actionCardsPanel;
    }
}
