package GUI.ADMIN;

import GUI.Vehicle.*;
import GUI.UIUtils;
import javax.swing.*;
import java.awt.*;

public class VehicleManagementWindow {
    public VehicleManagementWindow() {
        JFrame frame = new JFrame("SocietEase - Vehicle Management");
        frame.setSize(500, 400);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("Vehicle Management", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Buttons panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        JButton addVehicleButton = new JButton("Add Vehicle");
        UIUtils.styleButton(addVehicleButton);
        addVehicleButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addVehicleButton.addActionListener(e -> new AddVehicleForm());
        
        JButton removeVehicleButton = new JButton("Remove Vehicle");
        UIUtils.styleButton(removeVehicleButton);
        removeVehicleButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        removeVehicleButton.addActionListener(e -> new RemoveVehicleForm());
        
        JButton viewVehiclesButton = new JButton("View Vehicles");
        UIUtils.styleButton(viewVehiclesButton);
        viewVehiclesButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewVehiclesButton.addActionListener(e -> new ViewVehiclesWindow());
        
        buttonPanel.add(addVehicleButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(removeVehicleButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(viewVehiclesButton);
        
        mainPanel.add(buttonPanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
