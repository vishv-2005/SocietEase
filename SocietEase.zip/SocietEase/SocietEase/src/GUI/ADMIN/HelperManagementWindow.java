package GUI.ADMIN;

import GUI.Helper.*;
import GUI.UIUtils;
import javax.swing.*;
import java.awt.*;

public class HelperManagementWindow {
    public HelperManagementWindow() {
        JFrame frame = new JFrame("SocietEase - Helper Management");
        frame.setSize(500, 500);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("Helper Management", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Buttons panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        JButton addHelperButton = new JButton("Add Helper");
        UIUtils.styleButton(addHelperButton);
        addHelperButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addHelperButton.addActionListener(e -> new AddHelperForm());
        
        JButton assignHelperButton = new JButton("Assign Helper");
        UIUtils.styleButton(assignHelperButton);
        assignHelperButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        assignHelperButton.addActionListener(e -> new AssignHelperToApartment());
        
        JButton unassignHelperButton = new JButton("Unassign Helper");
        UIUtils.styleButton(unassignHelperButton);
        unassignHelperButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        unassignHelperButton.addActionListener(e -> new UnassignHelperForm());
        
        JButton removeHelperButton = new JButton("Remove Helper");
        UIUtils.styleButton(removeHelperButton);
        removeHelperButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        removeHelperButton.addActionListener(e -> new RemoveHelperForm());
        
        JButton viewHelpersButton = new JButton("View Helpers");
        UIUtils.styleButton(viewHelpersButton);
        viewHelpersButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewHelpersButton.addActionListener(e -> new ViewHelpersWindow());
        
        buttonPanel.add(addHelperButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(assignHelperButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(unassignHelperButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(removeHelperButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(viewHelpersButton);
        
        mainPanel.add(buttonPanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.dispose();
        frame.setVisible(true);
    }
}
