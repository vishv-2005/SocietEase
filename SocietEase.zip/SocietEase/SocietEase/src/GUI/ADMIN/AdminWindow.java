package GUI.ADMIN;

import GUI.USER.ResidentWindow;
import GUI.UIUtils;
import storage.DBConnector;
import models.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import javax.swing.border.*;
import java.util.List;

public class AdminWindow {
    private JFrame frame;
    private JPanel contentPanel;
    private JPanel statsPanel;
    private JPanel activityPanel;
    
    public AdminWindow() {
        frame = new JFrame("SocietEase - Admin Dashboard");
        frame.setSize(1200, 700);
        UIUtils.styleFrame(frame);
        
        // Main panel with modern layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        // Sidebar panel
        JPanel sidebarPanel = createSidebar();
        mainPanel.add(sidebarPanel, BorderLayout.WEST);
        
        // Content panel
        contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        
        // Welcome section
        JPanel welcomePanel = UIUtils.createCardPanel();
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.Y_AXIS));
        welcomePanel.setMaximumSize(new Dimension(800, 150));
        
        JLabel welcomeLabel = new JLabel("Welcome to Admin Dashboard");
        UIUtils.styleLabel(welcomeLabel, true);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Manage your society efficiently");
        subtitleLabel.setFont(UIUtils.NORMAL_FONT);
        subtitleLabel.setForeground(UIUtils.TEXT_COLOR);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        welcomePanel.add(Box.createRigidArea(new Dimension(0, 20)));
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createRigidArea(new Dimension(0, 10)));
        welcomePanel.add(subtitleLabel);
        welcomePanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        contentPanel.add(welcomePanel);
        contentPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Quick stats panel
        statsPanel = createQuickStatsPanel();
        contentPanel.add(statsPanel);
        contentPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Recent activity panel with table
        activityPanel = createRecentActivityPanel();
        contentPanel.add(activityPanel);
        
        // Add content panel to main panel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.setBackground(UIUtils.BACKGROUND_COLOR);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        // Start periodic updates
        startPeriodicUpdates();
    }
    
    private void startPeriodicUpdates() {
        Timer timer = new Timer(2000, e -> updateDashboard()); // Update every 2 seconds
        timer.start();
    }
    
    private void updateDashboard() {
        updateStatsPanel();
        updateActivityPanel();
    }
    
    private void updateStatsPanel() {
        statsPanel.removeAll();
        
        // Get live data from database
        List<Resident> residents = DBConnector.getAllResidents();
        List<Complaint> complaints = DBConnector.getAllComplaints();
        List<Vehicle> vehicles = DBConnector.getAllVehicles();
        
        // Count total residents (excluding NULL values)
        int totalResidents = 0;
        for (Resident resident : residents) {
            if (resident.getName() != null && !resident.getName().equals("NULL")) {
                totalResidents++;
            }
        }
        
        // Create stat cards
        String[] stats = {
            "Total Residents", String.valueOf(totalResidents),
            "Active Complaints", String.valueOf(complaints.size()),
            "Total Vehicles", String.valueOf(vehicles.size())
        };
        
        for (int i = 0; i < stats.length; i += 2) {
            JPanel statCard = UIUtils.createCardPanel();
            statCard.setLayout(new BoxLayout(statCard, BoxLayout.Y_AXIS));
            
            JLabel titleLabel = new JLabel(stats[i]);
            titleLabel.setFont(UIUtils.NORMAL_FONT);
            titleLabel.setForeground(UIUtils.TEXT_COLOR);
            titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            
            JLabel valueLabel = new JLabel(stats[i + 1]);
            valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
            valueLabel.setForeground(UIUtils.PRIMARY_COLOR);
            valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            
            statCard.add(Box.createRigidArea(new Dimension(0, 10)));
            statCard.add(titleLabel);
            statCard.add(Box.createRigidArea(new Dimension(0, 5)));
            statCard.add(valueLabel);
            statCard.add(Box.createRigidArea(new Dimension(0, 10)));
            
            statsPanel.add(statCard);
        }
        
        statsPanel.revalidate();
        statsPanel.repaint();
    }
    
    private void updateActivityPanel() {
        activityPanel.removeAll();
        
        // Notices Section
        JPanel noticesSection = new JPanel();
        noticesSection.setLayout(new BoxLayout(noticesSection, BoxLayout.Y_AXIS));
        noticesSection.setBackground(UIUtils.CARD_BACKGROUND);
        
        JPanel noticeHeader = new JPanel(new BorderLayout());
        noticeHeader.setBackground(UIUtils.CARD_BACKGROUND);
        
        JLabel noticeTitle = new JLabel("Recent Notices");
        UIUtils.styleLabel(noticeTitle, false);
        noticeTitle.setFont(UIUtils.HEADER_FONT);
        
        JButton issueNoticeBtn = new JButton("Issue New Notice");
        UIUtils.styleButton(issueNoticeBtn);
        issueNoticeBtn.addActionListener(e -> openIssueNoticeWindow());
        
        noticeHeader.add(noticeTitle, BorderLayout.WEST);
        noticeHeader.add(issueNoticeBtn, BorderLayout.EAST);
        
        // Create notices table
        String[] noticeColumns = {"Notice ID", "Content", "Issued By", "Date"};
        DefaultTableModel noticeModel = new DefaultTableModel(noticeColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable noticeTable = new JTable(noticeModel);
        styleTable(noticeTable);
        
        // Get notices and populate table
        List<Notice> notices = DBConnector.getAllNotices();
        for (Notice notice : notices) {
            noticeModel.addRow(new Object[]{
                notice.getNoticeID(),
                notice.getTitle(),
                notice.getIssuedBy(),
                notice.getDate()
            });
        }
        
        noticesSection.add(noticeHeader);
        noticesSection.add(Box.createRigidArea(new Dimension(0, 20)));
        noticesSection.add(new JScrollPane(noticeTable));
        
        // Committees Section
        JPanel committeesSection = new JPanel();
        committeesSection.setLayout(new BoxLayout(committeesSection, BoxLayout.Y_AXIS));
        committeesSection.setBackground(UIUtils.CARD_BACKGROUND);
        committeesSection.setBorder(BorderFactory.createEmptyBorder(30, 0, 0, 0));
        
        JLabel committeeTitle = new JLabel("Active Committees");
        UIUtils.styleLabel(committeeTitle, false);
        committeeTitle.setFont(UIUtils.HEADER_FONT);
        
        // Create committees table
        String[] committeeColumns = {"Committee ID","Committee Name","Description", "Head", "Apartment Number"};
        DefaultTableModel committeeModel = new DefaultTableModel(committeeColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable committeeTable = new JTable(committeeModel);
        styleTable(committeeTable);
        
        // Get committees and populate table
        List<Committee> committees = DBConnector.getAllCommittees();
        for (Committee committee : committees) {
            committeeModel.addRow(new Object[]{
                committee.getCommitteeID(),
                committee.getName(),
                committee.getDescription(),
                committee.getHead(),
                committee.getApartmentNumber(),
                
            });
        }
        
        committeesSection.add(committeeTitle);
        committeesSection.add(Box.createRigidArea(new Dimension(0, 20)));
        committeesSection.add(new JScrollPane(committeeTable));
        
        // Add both sections to activity panel
        activityPanel.add(noticesSection);
        activityPanel.add(committeesSection);
        
        activityPanel.revalidate();
        activityPanel.repaint();
    }
    
    private void styleTable(JTable table) {
        table.setBackground(UIUtils.CARD_BACKGROUND);
        table.setForeground(UIUtils.TEXT_COLOR);
        table.setFont(UIUtils.NORMAL_FONT);
        table.setRowHeight(30);
        table.getTableHeader().setBackground(UIUtils.PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(UIUtils.NORMAL_FONT);
    }
    
    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(UIUtils.PRIMARY_COLOR);
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        // Logo/Title
        JLabel logoLabel = new JLabel("SocietEase");
        logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        logoLabel.setForeground(Color.WHITE);
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        sidebar.add(logoLabel);
        
        // Navigation buttons
        String[] menuItems = {
            "Manage Residents",
            "Manage Helpers",
            "Manage Apartments",
            "Maintenance Records",
            "Manage Complaints",
            "Manage Committees",
            "Manage Vehicles",
            "Issue Notice"
        };
        
        for (String item : menuItems) {
            JButton menuButton = createMenuButton(item);
            sidebar.add(menuButton);
            sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
        }
        
        // Switch view button at bottom
        sidebar.add(Box.createVerticalGlue());
        JButton switchButton = new JButton("Switch to Resident View");
        switchButton.setFont(UIUtils.BUTTON_FONT);
        switchButton.setForeground(Color.WHITE);
        switchButton.setBackground(UIUtils.ACCENT_COLOR);
        switchButton.setFocusPainted(false);
        switchButton.setBorderPainted(false);
        switchButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        switchButton.setMaximumSize(new Dimension(200, 40));
        switchButton.addActionListener(e -> {
            new ResidentWindow();
            frame.dispose();
        });
        sidebar.add(switchButton);
        
        return sidebar;
    }
    
    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setFont(UIUtils.NORMAL_FONT);
        button.setForeground(Color.WHITE);
        button.setBackground(UIUtils.PRIMARY_COLOR);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(200, 40));
        
        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(UIUtils.SECONDARY_COLOR);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(UIUtils.PRIMARY_COLOR);
            }
        });
        
        // Add action listener based on text
        button.addActionListener(e -> {
            switch(text) {
                case "Manage Residents": openResidentManagementWindow(); break;
                case "Manage Helpers": openHelperManagementWindow(); break;
                case "Manage Apartments": openApartmentManagementWindow(); break;
                case "Maintenance Records": openViewMaintenanceWindow(); break;
                case "Manage Complaints": openComplaintManagementWindow(); break;
                case "Manage Committees": openCommitteeManagementWindow(); break;
                case "Manage Vehicles": openVehicleManagementWindow(); break;
                case "Issue Notice": openIssueNoticeWindow(); break;
            }
        });
        
        return button;
    }
    
    private JPanel createQuickStatsPanel() {
        JPanel statsPanel = new JPanel(new GridLayout(1, 3, 20, 0));
        statsPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        return statsPanel;
    }
    
    private JPanel createRecentActivityPanel() {
        JPanel activityPanel = UIUtils.createCardPanel();
        activityPanel.setLayout(new BoxLayout(activityPanel, BoxLayout.Y_AXIS));
        return activityPanel;
    }
    
    private void openResidentManagementWindow() {
        new ResidentManagementWindow();
    }
    
    private void openHelperManagementWindow() {
        new HelperManagementWindow();
    }
    
    private void openApartmentManagementWindow() {
        new ApartmentManagementWindow();
    }
    
    private void openViewMaintenanceWindow() {
        new ViewMaintenanceWindow();
    }
    
    private void openComplaintManagementWindow() {
        new ComplaintManagementWindow();
    }
    
    private void openCommitteeManagementWindow() {
        new CommitteeManagementWindow();
    }
    
    private void openVehicleManagementWindow() {
        new VehicleManagementWindow();
    }
    
    private void openIssueNoticeWindow() {
        new GUI.Notice.IssueNoticeForm();
    }
}
