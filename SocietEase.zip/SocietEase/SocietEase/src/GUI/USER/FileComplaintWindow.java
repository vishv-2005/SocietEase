package GUI.USER;

import GUI.UIUtils;
import models.Apartment;
import models.Complaint;
import storage.DBConnector;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.List;

public class FileComplaintWindow {

    public FileComplaintWindow() {
        JFrame frame = new JFrame("SocietEase - File a Complaint");
        frame.setSize(600, 500);
        UIUtils.styleFrame(frame);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);

        JLabel titleLabel = new JLabel("File a Complaint", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Date field
        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        UIUtils.styleLabel(dateLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(dateLabel, gbc);

        JTextField dateField = new JTextField(LocalDate.now().toString());
        UIUtils.styleTextField(dateField);
        gbc.gridx = 1;
        formPanel.add(dateField, gbc);

        // Apartment Combo Box
        JLabel apartmentLabel = new JLabel("Apartment Number:");
        UIUtils.styleLabel(apartmentLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(apartmentLabel, gbc);

        JComboBox<String> apartmentComboBox = new JComboBox<>();
        UIUtils.styleComboBox(apartmentComboBox);
        gbc.gridx = 1;
        formPanel.add(apartmentComboBox, gbc);

        List<Apartment> apartmentList = DBConnector.getAllApartments();
        for (Apartment a : apartmentList) {
            apartmentComboBox.addItem(a.getApartmentNumber());
        }

        // Description field
        JLabel descriptionLabel = new JLabel("Complaint Description:");
        UIUtils.styleLabel(descriptionLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(descriptionLabel, gbc);

        JTextArea descriptionArea = new JTextArea(5, 20);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(descriptionArea);
        scrollPane.setPreferredSize(new Dimension(300, 100));
        gbc.gridx = 1;
        formPanel.add(scrollPane, gbc);

        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        

        // Submit button
        JButton submitButton = new JButton("Submit Complaint");
        UIUtils.styleButton(submitButton);
        submitButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        submitButton.addActionListener(e -> {
            String date = dateField.getText().trim();
            String apartmentNumber = (String) apartmentComboBox.getSelectedItem();
            String description = descriptionArea.getText().trim();

            if (date.isEmpty() || apartmentNumber == null || description.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                Complaint complaint = new Complaint();
                complaint.setDateFiled(LocalDate.parse(date));
                complaint.setApartmentNumber(apartmentNumber);
                complaint.setDescription(description);
                DBConnector.addComplaint(complaint);

                JOptionPane.showMessageDialog(frame, "✅ Complaint filed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Clear fields
                descriptionArea.setText("");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }

        });

        
        
        mainPanel.add(submitButton);

        

        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
