package GUI.USER;

import GUI.UIUtils;
import models.Maintenance;
import models.Resident;
import storage.DBConnector;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class PayMaintenanceWindow {
    public PayMaintenanceWindow() {
        JFrame frame = new JFrame("SocietEase - Pay Maintenance");
        frame.setSize(600, 650);
        UIUtils.styleFrame(frame);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);

        JLabel titleLabel = new JLabel("Pay Maintenance", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        JPanel formPanel = new JPanel(new GridBagLayout());
        UIUtils.stylePanel(formPanel);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Resident ComboBox
        JLabel nameLabel = new JLabel("Select Resident:");
        UIUtils.styleLabel(nameLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(nameLabel, gbc);

        JComboBox<Resident> residentComboBox = new JComboBox<>();
        UIUtils.styleComboBox(residentComboBox);
        gbc.gridx = 1;
        formPanel.add(residentComboBox, gbc);

        // Apartment field
        JLabel apartmentLabel = new JLabel("Apartment Number:");
        UIUtils.styleLabel(apartmentLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(apartmentLabel, gbc);

        JTextField apartmentField = new JTextField(20);
        apartmentField.setEditable(false);
        UIUtils.styleTextField(apartmentField);
        gbc.gridx = 1;
        formPanel.add(apartmentField, gbc);

        // Amount field
        JLabel amountLabel = new JLabel("Amount Paid:");
        UIUtils.styleLabel(amountLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(amountLabel, gbc);

        JTextField amountField = new JTextField(20);
        UIUtils.styleTextField(amountField);
        gbc.gridx = 1;
        formPanel.add(amountField, gbc);

        // Mode of payment
        JLabel modeLabel = new JLabel("Mode of Payment:");
        UIUtils.styleLabel(modeLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(modeLabel, gbc);

        String[] paymentModes = {"Cash", "Online", "Cheque"};
        JComboBox<String> paymentModeCombo = new JComboBox<>(paymentModes);
        UIUtils.styleComboBox(paymentModeCombo);
        gbc.gridx = 1;
        formPanel.add(paymentModeCombo, gbc);

        // Date field
        JLabel dateLabel = new JLabel("Payment Date (YYYY-MM-DD):");
        UIUtils.styleLabel(dateLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(dateLabel, gbc);

        JTextField dateField = new JTextField(LocalDate.now().toString());
        UIUtils.styleTextField(dateField);
        gbc.gridx = 1;
        formPanel.add(dateField, gbc);

        // Contact field
        JLabel contactLabel = new JLabel("Contact Info:");
        UIUtils.styleLabel(contactLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(contactLabel, gbc);

        JTextField contactField = new JTextField(20);
        contactField.setEditable(false);
        UIUtils.styleTextField(contactField);
        gbc.gridx = 1;
        formPanel.add(contactField, gbc);

        // Load residents into combo
        List<Resident> residents = DBConnector.getAllResidents();
        for (Resident r : residents) {
            residentComboBox.addItem(r);
        }

        // On resident selection -> fill apartment & contact
        residentComboBox.addActionListener(e -> {
            Resident selected = (Resident) residentComboBox.getSelectedItem();
            if (selected != null) {
                apartmentField.setText(selected.getApartmentNumber());
                contactField.setText(selected.getContactInfo());
            }
        });

        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Submit button
        JButton submitButton = new JButton("Submit Payment");
        UIUtils.styleButton(submitButton);
        submitButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        submitButton.addActionListener(e -> {
            Resident selected = (Resident) residentComboBox.getSelectedItem();
            String amount = amountField.getText().trim();
            String paymentMode = (String) paymentModeCombo.getSelectedItem();
            String date = dateField.getText().trim();

            if (selected == null || amount.isEmpty() || date.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                Maintenance m = new Maintenance();
                m.setName(selected.getName());
                m.setApartmentNumber(selected.getApartmentNumber());
                m.setContactInfo(selected.getContactInfo());
                m.setAmountPaid(Double.parseDouble(amount));
                m.setModeOfPayment(paymentMode);
                m.setPaymentDate(LocalDate.parse(date));

                storage.DBConnector.addMaintenanceRecord(m);

                JOptionPane.showMessageDialog(frame, "✅ Payment recorded successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                amountField.setText("");
                dateField.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        mainPanel.add(submitButton);

        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
