package GUI.USER;

import GUI.Notice.ViewNoticesWindow;
import GUI.UIUtils;
import storage.DBConnector;
import models.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import javax.swing.border.*;
import java.util.List;

public class ResidentWindow {

    private JFrame frame;
    private JPanel contentPanel;
    private JPanel noticesPanel;

    public ResidentWindow() {
        frame = new JFrame("SocietEase - Resident Dashboard");
        frame.setSize(1200, 700);
        UIUtils.styleFrame(frame);

        // Main panel with modern layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UIUtils.BACKGROUND_COLOR);

        // Top navigation bar
        JPanel topBar = createTopBar();
        mainPanel.add(topBar, BorderLayout.NORTH);

        // Content panel
        contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        // Welcome section
        JPanel welcomePanel = UIUtils.createCardPanel();
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.Y_AXIS));
        welcomePanel.setMaximumSize(new Dimension(800, 150));

        JLabel welcomeLabel = new JLabel("Welcome to Your Dashboard");
        UIUtils.styleLabel(welcomeLabel, true);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitleLabel = new JLabel("Manage your society activities");
        subtitleLabel.setFont(UIUtils.NORMAL_FONT);
        subtitleLabel.setForeground(UIUtils.TEXT_COLOR);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        welcomePanel.add(Box.createRigidArea(new Dimension(0, 20)));
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createRigidArea(new Dimension(0, 10)));
        welcomePanel.add(subtitleLabel);
        welcomePanel.add(Box.createRigidArea(new Dimension(0, 20)));

        contentPanel.add(welcomePanel);
        contentPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Quick actions panel
        JPanel quickActionsPanel = createQuickActionsPanel();
        contentPanel.add(quickActionsPanel);
        contentPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Recent notices panel
        noticesPanel = createRecentNoticesPanel();
        contentPanel.add(noticesPanel);

        // Add content panel to main panel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.setBackground(UIUtils.BACKGROUND_COLOR);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        // Start periodic updates
        startPeriodicUpdates();
    }

    private void startPeriodicUpdates() {
        Timer timer = new Timer(2000, e -> updateNotices()); // Update every 5 seconds
        timer.start();
    }

    private void updateNotices() {
        noticesPanel.removeAll();

        // Notices Section
        JPanel noticesSection = new JPanel();
        noticesSection.setLayout(new BoxLayout(noticesSection, BoxLayout.Y_AXIS));
        noticesSection.setBackground(UIUtils.CARD_BACKGROUND);

        JLabel noticeTitle = new JLabel("Recent Notices");
        UIUtils.styleLabel(noticeTitle, false);
        noticeTitle.setFont(UIUtils.HEADER_FONT);

        // Create notices table
        String[] noticeColumns = {"Notice ID", "Content", "Issued By", "Date"};
        DefaultTableModel noticeModel = new DefaultTableModel(noticeColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable noticeTable = new JTable(noticeModel);
        styleTable(noticeTable);

        // Get notices and populate table
        List<Notice> notices = DBConnector.getAllNotices();
        for (Notice notice : notices) {
            noticeModel.addRow(new Object[]{
                notice.getNoticeID(),
                notice.getTitle(),
                notice.getIssuedBy(),
                notice.getDate(),});
        }

        noticesSection.add(noticeTitle);
        noticesSection.add(Box.createRigidArea(new Dimension(0, 20)));
        noticesSection.add(new JScrollPane(noticeTable));

        // Helpers Section
        JPanel helpersSection = new JPanel();
        helpersSection.setLayout(new BoxLayout(helpersSection, BoxLayout.Y_AXIS));
        helpersSection.setBackground(UIUtils.CARD_BACKGROUND);
        helpersSection.setBorder(BorderFactory.createEmptyBorder(30, 0, 0, 0));

        JLabel helperTitle = new JLabel("Available Helpers");
        UIUtils.styleLabel(helperTitle, false);
        helperTitle.setFont(UIUtils.HEADER_FONT);

        // Create helpers table
        String[] helperColumns = {"Helper ID", "Name", "Role", "Salary", "Contact", "Aadhar Number"};
        DefaultTableModel helperModel = new DefaultTableModel(helperColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable helperTable = new JTable(helperModel);
        styleTable(helperTable);

        // Get helpers and populate table
        List<Helper> helpers = DBConnector.getAllHelpers();
        for (Helper helper : helpers) {
            helperModel.addRow(new Object[]{
                helper.getHelperID(),
                helper.getName(),
                helper.getRole(),
                helper.getSalary(),
                helper.getContactInfo(),
                helper.getAadharNumber(),});
        }

        helpersSection.add(helperTitle);
        helpersSection.add(Box.createRigidArea(new Dimension(0, 20)));
        helpersSection.add(new JScrollPane(helperTable));

        // Committees Section
        JPanel committeesSection = new JPanel();
        committeesSection.setLayout(new BoxLayout(committeesSection, BoxLayout.Y_AXIS));
        committeesSection.setBackground(UIUtils.CARD_BACKGROUND);
        committeesSection.setBorder(BorderFactory.createEmptyBorder(30, 0, 0, 0));

        JLabel committeeTitle = new JLabel("Active Committees");
        UIUtils.styleLabel(committeeTitle, false);
        committeeTitle.setFont(UIUtils.HEADER_FONT);

        // Create committees table
        String[] committeeColumns = {"Committee ID", "Committee Name", "Description", "Head", "Apartment Number"};
        DefaultTableModel committeeModel = new DefaultTableModel(committeeColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable committeeTable = new JTable(committeeModel);
        styleTable(committeeTable);

        // Get committees and populate table
        List<Committee> committees = DBConnector.getAllCommittees();
        for (Committee committee : committees) {
            committeeModel.addRow(new Object[]{
                committee.getCommitteeID(),
                committee.getName(),
                committee.getDescription(),
                committee.getHead(),
                committee.getApartmentNumber(),});
        }

        committeesSection.add(committeeTitle);
        committeesSection.add(Box.createRigidArea(new Dimension(0, 20)));
        committeesSection.add(new JScrollPane(committeeTable));

        // Add all sections to notices panel
        noticesPanel.add(noticesSection);
        noticesPanel.add(helpersSection);
        noticesPanel.add(committeesSection);

        noticesPanel.revalidate();
        noticesPanel.repaint();
    }

    private void styleTable(JTable table) {
        table.setBackground(UIUtils.CARD_BACKGROUND);
        table.setForeground(UIUtils.TEXT_COLOR);
        table.setFont(UIUtils.NORMAL_FONT);
        table.setRowHeight(30);
        table.getTableHeader().setBackground(UIUtils.PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(UIUtils.NORMAL_FONT);
    }

    private JPanel createTopBar() {
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UIUtils.PRIMARY_COLOR);
        topBar.setPreferredSize(new Dimension(0, 60));
        topBar.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        // Logo/Title
        JLabel logoLabel = new JLabel("SocietEase");
        logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        logoLabel.setForeground(Color.WHITE);
        topBar.add(logoLabel, BorderLayout.WEST);

        // Switch to Admin button
        JButton switchToAdminButton = new JButton("Switch to Admin View");
        switchToAdminButton.setFont(UIUtils.BUTTON_FONT);
        switchToAdminButton.setForeground(Color.WHITE);
        switchToAdminButton.setBackground(UIUtils.ACCENT_COLOR);
        switchToAdminButton.setFocusPainted(false);
        switchToAdminButton.setBorderPainted(false);
        switchToAdminButton.addActionListener(e -> {
            new GUI.ADMIN.AdminWindow();
            frame.dispose();
        });

        topBar.add(switchToAdminButton, BorderLayout.EAST);

        return topBar;
    }

    private JPanel createQuickActionsPanel() {
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); // Horizontal layout with spacing
        actionsPanel.setBackground(UIUtils.BACKGROUND_COLOR);

        // Create action cards
        String[] actions = {
            "Pay Maintenance", "File Complaint", "View Vehicles"
        };

        for (String action : actions) {
            JPanel actionCard = UIUtils.createCardPanel();
            actionCard.setLayout(new BoxLayout(actionCard, BoxLayout.Y_AXIS));
            actionCard.setPreferredSize(new Dimension(220, 150)); // Smaller size for all to fit in one row

            JLabel titleLabel = new JLabel(action);
            titleLabel.setFont(UIUtils.HEADER_FONT);
            titleLabel.setForeground(UIUtils.TEXT_COLOR);
            titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            JButton actionButton = new JButton("Open");
            UIUtils.styleButton(actionButton);
            actionButton.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Add action listener based on text
            actionButton.addActionListener(e -> {
                switch (action) {
                    case "Pay Maintenance":
                        openPayMaintenanceWindow();
                        break;
                    case "File Complaint":
                        openFileComplaintWindow();
                        break;
                    case "View Vehicles":
                        openViewVehiclesWindow();
                        break;
                }
            });

            actionCard.add(Box.createRigidArea(new Dimension(0, 10)));
            actionCard.add(titleLabel);
            actionCard.add(Box.createRigidArea(new Dimension(0, 10)));
            actionCard.add(actionButton);

            actionsPanel.add(actionCard);
        }

        return actionsPanel;
    }

    private JPanel createRecentNoticesPanel() {
        JPanel noticesPanel = UIUtils.createCardPanel();
        noticesPanel.setLayout(new BoxLayout(noticesPanel, BoxLayout.Y_AXIS));
        return noticesPanel;
    }

    private void openPayMaintenanceWindow() {
        new PayMaintenanceWindow();
    }

    private void openViewVehiclesWindow() {
        new GUI.Vehicle.ViewUserVehiclesWindow();
    }

    private void openFileComplaintWindow() {
        new FileComplaintWindow();
    }
}
