package GUI.Helper;

import javax.swing.*;
import java.awt.event.*;
import java.util.List;
import models.Helper;
import storage.DBConnector;

public class RemoveHelperForm {
    public RemoveHelperForm() {
        JFrame frame = new JFrame("Remove Helper");
        frame.setSize(400, 200);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel helperLabel = new JLabel("Select Helper:");
        helperLabel.setBounds(50, 40, 120, 30);
        frame.add(helperLabel);

        JComboBox<String> helperComboBox = new JComboBox<>();
        helperComboBox.setBounds(170, 40, 150, 30);
        frame.add(helperComboBox);

        // Populate dropdown
        List<Helper> helpers = DBConnector.getAllHelpers();
        for (Helper helper : helpers) {
            helperComboBox.addItem(helper.getHelperID() + " - " + helper.getName());
        }

        JButton removeButton = new JButton("Remove");
        removeButton.setBounds(130, 100, 120, 30);
        frame.add(removeButton);

        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selected = (String) helperComboBox.getSelectedItem();
                if (selected == null) {
                    JOptionPane.showMessageDialog(frame, "No helper selected.");
                    return;
                }

                String helperID = selected.split(" - ")[0]; // Extract helper ID

                boolean removed = DBConnector.removeHelperByID(helperID);
                if (removed) {
                    JOptionPane.showMessageDialog(frame, "Helper removed successfully.");
                    frame.dispose();
                } else {
                    JOptionPane.showMessageDialog(frame, "Failed to remove helper.");
                }
            }
        });

        frame.setVisible(true);
    }
}
