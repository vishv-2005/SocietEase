package GUI.Helper;

import GUI.UIUtils;
import models.Helper;
import storage.DBConnector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ViewHelpersWindow {
    public ViewHelpersWindow() {
        JFrame frame = new JFrame("SocietEase - View Helpers");
        frame.setSize(800, 500);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("View Helpers", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(UIUtils.BACKGROUND_COLOR);
        
        String[] columns = {"Helper ID", "Name", "Role", "Salary", "Contact", "Aadhar Number"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        UIUtils.styleTable(table);
        
        JScrollPane scrollPane = new JScrollPane(table);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Fetch data from DB and fill table
        List<Helper> helperList = DBConnector.getAllHelpers();
        for (Helper helper : helperList) {
            model.addRow(new Object[]{
                helper.getHelperID(),
                helper.getName(),
                helper.getRole(),
                helper.getSalary(),
                helper.getContactInfo(),
                helper.getAadharNumber()
            });
        }
        
        mainPanel.add(tablePanel);
        frame.add(mainPanel);
        
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
