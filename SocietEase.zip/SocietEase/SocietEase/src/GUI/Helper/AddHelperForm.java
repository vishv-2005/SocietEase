package GUI.Helper;

import GUI.UIUtils;
import models.Helper;
import storage.DBConnector;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddHelperForm {
    public AddHelperForm() {
        JFrame frame = new JFrame("SocietEase - Add Helper");
        frame.setSize(600, 600);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("Add Helper", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Name field
        JLabel nameLabel = new JLabel("Name:");
        UIUtils.styleLabel(nameLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(nameLabel, gbc);
        
        JTextField nameField = new JTextField(20);
        UIUtils.styleTextField(nameField);
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(nameField, gbc);
        
        // Role field
        JLabel roleLabel = new JLabel("Role:");
        UIUtils.styleLabel(roleLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(roleLabel, gbc);
        
        JTextField roleField = new JTextField(20);
        UIUtils.styleTextField(roleField);
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(roleField, gbc);
        
        //Enter Facility
        nameField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                roleField.requestFocus();
            }
        });
        
        // Salary field
        JLabel salaryLabel = new JLabel("Salary:");
        UIUtils.styleLabel(salaryLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(salaryLabel, gbc);
        
        JTextField salaryField = new JTextField(20);
        UIUtils.styleTextField(salaryField);
        gbc.gridx = 1;
        gbc.gridy = 2;
        formPanel.add(salaryField, gbc);
        
        //Enter Facility
        roleField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salaryField.requestFocus();
            }
        });
        
        // Contact field
        JLabel contactLabel = new JLabel("Contact Info:");
        UIUtils.styleLabel(contactLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(contactLabel, gbc);
        
        JTextField contactField = new JTextField(20);
        UIUtils.styleTextField(contactField);
        gbc.gridx = 1;
        gbc.gridy = 3;
        formPanel.add(contactField, gbc);
        
        //Enter Facility
        roleField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                contactField.requestFocus();
            }
        });
        
        // Aadhar field
        JLabel aadharLabel = new JLabel("Aadhar Number:");
        UIUtils.styleLabel(aadharLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(aadharLabel, gbc);
        
        JTextField aadharField = new JTextField(20);
        UIUtils.styleTextField(aadharField);
        gbc.gridx = 1;
        gbc.gridy = 4;
        formPanel.add(aadharField, gbc);
        
        //Enter Facility
        contactField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                aadharField.requestFocus();
            }
        });
        
        
        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Add button
        JButton addButton = new JButton("Add Helper");
        UIUtils.styleButton(addButton);
        addButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addButton.addActionListener(e -> {
            String name = nameField.getText();
            String role = roleField.getText();
            String salaryStr = salaryField.getText();
            String contactInfo = contactField.getText();
            String aadharStr = aadharField.getText();
            
            if (name.isEmpty() || role.isEmpty() || salaryStr.isEmpty() || contactInfo.isEmpty() || aadharStr.isEmpty()) {
                JOptionPane.showMessageDialog(frame, 
                    "Please fill all fields.", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            try {
                double salary = Double.parseDouble(salaryStr);
                long aadharNumber = Long.parseLong(aadharStr);
                
                Helper helper = new Helper();
                helper.setName(name);
                helper.setRole(role);
                helper.setAadharNumber(aadharNumber);
                helper.setContactInfo(contactInfo);
                helper.setSalary(salary);
                
                DBConnector.addHelper(helper);
                
                JOptionPane.showMessageDialog(frame, 
                    "Helper added successfully!", 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                    frame.dispose();
                
                // Clear fields
                nameField.setText("");
                roleField.setText("");
                salaryField.setText("");
                contactField.setText("");
                aadharField.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, 
                    "Please enter valid numbers for Salary and Aadhar!", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, 
                    "Error: " + ex.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        
        mainPanel.add(addButton);
        
        //Enter Facility
        aadharField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addButton.doClick();
            }
        });
        
        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
