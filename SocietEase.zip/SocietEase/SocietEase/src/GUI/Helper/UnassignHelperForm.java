package GUI.Helper;

import GUI.UIUtils;
import models.Apartment;
import models.Helper;
import storage.DBConnector;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class UnassignHelperForm {
    public UnassignHelperForm() {
        JFrame frame = new JFrame("SocietEase - Unassign Helper");
        frame.setSize(500, 400);
        UIUtils.styleFrame(frame);

        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);

        // Title
        JLabel titleLabel = new JLabel("Unassign Helper from Apartment", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Apartment ComboBox
        JLabel aptLabel = new JLabel("Select Apartment:");
        UIUtils.styleLabel(aptLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(aptLabel, gbc);

        JComboBox<String> aptCombo = new JComboBox<>();
        aptCombo.setFont(UIUtils.NORMAL_FONT);
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(aptCombo, gbc);

        // Helper ComboBox
        JLabel helperLabel = new JLabel("Select Helper:");
        UIUtils.styleLabel(helperLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(helperLabel, gbc);

        JComboBox<String> helperCombo = new JComboBox<>();
        helperCombo.setFont(UIUtils.NORMAL_FONT);
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(helperCombo, gbc);

        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Button Panel (Load + Unassign side by side)
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
        buttonPanel.setBackground(UIUtils.BACKGROUND_COLOR);

        JButton loadHelpersButton = new JButton("Load Helpers");
        UIUtils.styleButton(loadHelpersButton);
        buttonPanel.add(loadHelpersButton);

        JButton unassignButton = new JButton("Unassign Helper");
        UIUtils.styleButton(unassignButton);
        buttonPanel.add(unassignButton);

        mainPanel.add(buttonPanel);

        // Load apartments into combo
        List<Apartment> apartments = DBConnector.getAllApartments();
        for (Apartment apt : apartments) {
            aptCombo.addItem(apt.getApartmentNumber());
        }

        // Load Helpers Button Click
        loadHelpersButton.addActionListener(e -> {
            String selectedApt = (String) aptCombo.getSelectedItem();
            if (selectedApt == null) {
                JOptionPane.showMessageDialog(frame, "Please select an apartment first.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            List<Helper> assignedHelpers = DBConnector.getHelpersForApartment(selectedApt);
            helperCombo.removeAllItems();

            if (assignedHelpers.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "No helpers assigned to this apartment.", "Info", JOptionPane.INFORMATION_MESSAGE);
            } else {
                for (Helper helper : assignedHelpers) {
                    helperCombo.addItem(helper.getHelperID() + " - " + helper.getName());
                }
            }
        });

        // Unassign Button Click
        unassignButton.addActionListener(e -> {
            String selectedApt = (String) aptCombo.getSelectedItem();
            String selectedHelper = (String) helperCombo.getSelectedItem();

            if (selectedApt == null || selectedHelper == null) {
                JOptionPane.showMessageDialog(frame,
                        "Please select both apartment and helper.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                String helperID = selectedHelper.split(" - ")[0];
                DBConnector.unassignHelperFromApartment(selectedApt, helperID);

                JOptionPane.showMessageDialog(frame,
                        "Helper unassigned successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);

                helperCombo.removeItem(selectedHelper); // remove from UI
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame,
                        "Error: " + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        // Final frame settings
        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
