package GUI.Helper;

import GUI.UIUtils;
import models.Apartment;
import models.Helper;
import storage.DBConnector;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AssignHelperToApartment {
    public AssignHelperToApartment() {
        JFrame frame = new JFrame("SocietEase - Assign Helper");
        frame.setSize(500, 400);
        UIUtils.styleFrame(frame);
        
        // Main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        UIUtils.stylePanel(mainPanel);
        
        // Title
        JLabel titleLabel = new JLabel("Assign Helper to Apartment", SwingConstants.CENTER);
        UIUtils.styleLabel(titleLabel, true);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Select apartment
        JLabel aptLabel = new JLabel("Select Apartment:");
        UIUtils.styleLabel(aptLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(aptLabel, gbc);
        
        JComboBox<String> aptCombo = new JComboBox<>();
        aptCombo.setFont(UIUtils.NORMAL_FONT);
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(aptCombo, gbc);
        
        // Select helper
        JLabel helperLabel = new JLabel("Select Helper:");
        UIUtils.styleLabel(helperLabel, false);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(helperLabel, gbc);
        
        JComboBox<String> helperCombo = new JComboBox<>();
        helperCombo.setFont(UIUtils.NORMAL_FONT);
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(helperCombo, gbc);
        
        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Load apartments into combo box
        List<Apartment> apartments = DBConnector.getAllApartments();
        for (Apartment apartment : apartments) {
            aptCombo.addItem(apartment.getApartmentNumber());
        }
        
        // Load helpers into combo box
        List<Helper> helpers = DBConnector.getAllHelpers();
        for (Helper helper : helpers) {
            helperCombo.addItem(helper.getHelperID() + " - " + helper.getName());
        }
        
        // Assign button
        JButton assignButton = new JButton("Assign Helper");
        UIUtils.styleButton(assignButton);
        assignButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        assignButton.addActionListener(e -> {
            String selectedApt = (String) aptCombo.getSelectedItem();
            String selectedHelper = (String) helperCombo.getSelectedItem();
            
            if (selectedApt == null || selectedHelper == null) {
                JOptionPane.showMessageDialog(frame, 
                    "Please select both apartment and helper.", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            try {
                String helperID = selectedHelper.split(" - ")[0];
                DBConnector.assignHelperToApartment(selectedApt, helperID);
                
                JOptionPane.showMessageDialog(frame, 
                    "Helper assigned successfully!", 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                frame.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, 
                    "Error: " + ex.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        
        mainPanel.add(assignButton);
        
        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
