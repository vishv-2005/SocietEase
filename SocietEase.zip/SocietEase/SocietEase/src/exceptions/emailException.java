package exceptions;
/**
 *
 * @author vishv
 */
public class emailException extends ExceptionHandler
{
    public emailException() 
    {
        super("Please Enter a Valid Email....");
    }
}
