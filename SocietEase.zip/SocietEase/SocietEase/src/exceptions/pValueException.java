package exceptions;
/**
 *
 * @author vishv
 */
public class pValueException extends ExceptionHandler
{
    public pValueException()
    {
        super("Please enter Valid amount : ");
    }
}
