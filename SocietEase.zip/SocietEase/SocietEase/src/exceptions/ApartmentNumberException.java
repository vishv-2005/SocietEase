package exceptions;
/**
 *
 * @author vishv
 */
public class ApartmentNumberException extends ExceptionHandler 
{

    public ApartmentNumberException() 
    {
        super("Give a Valid Apartment Number Input...(101,102,103,104,201,.....504)");
    }
}
