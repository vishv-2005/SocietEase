package exceptions;
/**
 *
 * @author vishv
 */
public class ExceptionHandler extends Exception
{
     public ExceptionHandler(String message) 
    {
        super(message);
    }
}
