package exceptions;
/**
 *
 * @author vishv
 */
public class OwnerTenantException extends ExceptionHandler
{
    public OwnerTenantException() 
    {
        super("Please Enter  Owner/Tenant.");
    }
}
