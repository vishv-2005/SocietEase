package exceptions;
/**
 *
 * @author vishv
 */
public class rName extends ExceptionHandler
{
    public rName() 
    {
        super("Name is not Valid, Please provide characters only!!!");
    }
}
