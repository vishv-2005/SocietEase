package exceptions;
/**
 *
 * @author vishv
 */
public class PmodeException extends ExceptionHandler
{
    public PmodeException() 
    {
        super("Please Enter Payment Mode Online/Cash/Cheque.");
    }
}
