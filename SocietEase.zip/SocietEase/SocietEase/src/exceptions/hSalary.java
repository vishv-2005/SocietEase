package exceptions;

/**
 *
 * @author vishv
 */
public class hSalary extends ExceptionHandler
{
        public hSalary()
    {
        super("Enter Numeric Value Only!!!");
    }
}
