package exceptions;
/**
 *
 * @author vishv
 */
public class ContactNumberException extends ExceptionHandler 
{

    public ContactNumberException() 
    {
        super("Contact Number must be exactly 10 digits");
    }
}
