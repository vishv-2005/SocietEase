package exceptions;

/**
 *
 * @author vishv
 */
public class hRole extends ExceptionHandler
{
    public hRole() 
    {
        super("Please Enter valid Role!!!");
    }
}
