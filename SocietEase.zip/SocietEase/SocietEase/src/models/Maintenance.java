package models;

import java.time.LocalDate;

public class Maintenance {
    private String maintenanceID;
    private String name;
    private String apartmentNumber;
    private double amountPaid;
    private String modeOfPayment;
    private LocalDate paymentDate;
    private String contactInfo;

    public Maintenance(String maintenanceID, String name, String apartmentNumber, double amountPaid, String modeOfPayment, LocalDate paymentDate, String contactInfo) {
        
        this.maintenanceID = maintenanceID;
        this.name = name;
        this.apartmentNumber = apartmentNumber;
        this.amountPaid = amountPaid;
        this.modeOfPayment = modeOfPayment;
        this.paymentDate = paymentDate;
        this.contactInfo = contactInfo;
    }

    public Maintenance() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters
    public String getmaintenanceID(){ return maintenanceID;}
    public String getName() { return name; }
    public String getApartmentNumber() { return apartmentNumber; }
    public double getAmountPaid() { return amountPaid; }
    public String getModeOfPayment() { return modeOfPayment; }
    public LocalDate getPaymentDate() { return paymentDate; }
    public String getContactInfo() { return contactInfo; }

    // Setters
    public void setMaintenanceID(String maintenanceID){ this.maintenanceID = maintenanceID;}
    public void setName(String name) { this.name = name; }
    public void setApartmentNumber(String apartmentNumber) {this.apartmentNumber = apartmentNumber; }
    public void setAmountPaid(double amountPaid) { this.amountPaid = amountPaid; }
    public void setModeOfPayment(String modeOfPayment) { this.modeOfPayment = modeOfPayment; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }
    public void setContactInfo(String contactInfo) { this.contactInfo = contactInfo; }

    @Override
    public String toString() {
        return "Maintenance [Name=" + name + ", Apartment=" + apartmentNumber + ", Amount=" + amountPaid +
               ", Mode=" + modeOfPayment + ", Date=" + paymentDate + ", Contact=" + contactInfo + "]";
    }   
}
