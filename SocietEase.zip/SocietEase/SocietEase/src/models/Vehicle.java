package models;

public class Vehicle {
    private String registrationNumber;
    private String apartmentNumber;
    private String ownerName;
    private String type; // 2-Wheeler or 4-Wheeler

    public Vehicle(String registrationNumber, String apartmentNumber, String ownerName, String type) {
        this.registrationNumber = registrationNumber;
        this.apartmentNumber = apartmentNumber;
        this.ownerName = ownerName;
        this.type = type;
    }

    public Vehicle() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
  //// Getters
    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public String getApartmentNumber() {
        return apartmentNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public String getType() {
        return type;
    }
    
    ///Setter
    
    public void setRegistrationNumber(String registrationNumber) { this.registrationNumber = registrationNumber;}
    public void setApartmentNumber(String apartmentNumber) { this.apartmentNumber = apartmentNumber;}
    public void setOwnerName(String ownername) { this.ownerName = ownername; }
    public void setType(String type) {this.type = type;}

    @Override
    public String toString() {
        return "Vehicle Registration: " + registrationNumber +
               "\nOwner: " + ownerName +
               "\nApartment: " + apartmentNumber +
               "\nType: " + type +
               "\n---------------------------";
    }  
}
