package models;

public class Resident {
    private String name;
    private String contactInfo;
    private final String apartmentNumber;  // 🔹 Made it FINAL
    private String email;

    // Constructor
    public Resident(String name, String contactInfo, String apartmentNumber, String email) {
        this.name = name;
        this.contactInfo = contactInfo;
        this.apartmentNumber = apartmentNumber;
        this.email = email;
    }

    public Resident() {
        this.apartmentNumber = "";  // 🔹 Ensure it is always initialized
    }

    // Getters
    public String getName() { return name; }
    public String getContactInfo() { return contactInfo; }
    public String getApartmentNumber() { return apartmentNumber; }
    public String getEmail() { return email; }

    // Setters (Removed setApartmentNumber) 🔹
    public void setName(String name) { this.name = name; }
    public void setContactInfo(String contactInfo) { this.contactInfo = contactInfo; }
    public void setEmail(String email) { this.email = email; }

    // Override toString() for better display
    @Override
    public String toString() {
        return name;
    }
}
