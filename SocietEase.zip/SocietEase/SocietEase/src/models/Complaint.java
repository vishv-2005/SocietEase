package models;

import java.time.LocalDate;

public class Complaint {
    private String complaintID;
    private LocalDate dateFiled;
    private String apartmentNumber;
    private String description;
    private boolean resolved;

    public Complaint(String complaintID, String apartmentNumber, String description) {
        this.complaintID = complaintID;
        this.dateFiled = LocalDate.now();
        this.apartmentNumber = apartmentNumber;
        this.description = description;
        this.resolved = false;
    }

    public Complaint() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public LocalDate getDateFiled() {
        return dateFiled;
    }
    
    public void setDateFiled(LocalDate dateFiled) {
        this.dateFiled = LocalDate.now();
    }
    
    public String getComplaintID(){
        return complaintID;
    }
    
    public void setComplaintID(String complaintID){
        this.complaintID = complaintID;
    }
    
    public String getApartmentNumber() {
        return apartmentNumber;
    }
    
    public void setApartmentNumber(String apartmentNumber) {
        this.apartmentNumber = apartmentNumber;
    }

    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isResolved() {
        return resolved;
    }

    public void markResolved() {
        this.resolved = true;
    }

    @Override
    public String toString() {
        return "Complaint Filed On: " + dateFiled +
               "\nApartment Number: " + apartmentNumber +
               "\nDescription: " + description +
               "\nStatus: " + (resolved ? "Resolved" : "Pending") +
               "\n---------------------------";
    }

    
}
