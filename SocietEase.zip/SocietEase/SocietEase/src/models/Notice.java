package models;

import java.time.LocalDate;

public class Notice {
    private String noticeID;
    private LocalDate date;
    private String title;
    private String content;
    private int issuedBy;

    public Notice(String noticeID, String title, String content, int issuedBy) {
        this.noticeID = noticeID;
        this.date = LocalDate.now();
        this.title = title;
        this.content = content;
        this.issuedBy = issuedBy;
    }

    public Notice() {}

    public String getNoticeID() { return noticeID; }
    public LocalDate getDate() { return date; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public int getIssuedBy() { return issuedBy; }

    public void setNoticeID(String noticeID) { this.noticeID = noticeID; }
    public void setDate(LocalDate date) { this.date = date; }
    public void setTitle(String title) { this.title = title; }
    public void setContent(String content) { this.content = content; }
    public void setIssuedBy(int issuedBy) { this.issuedBy = issuedBy; }

    @Override
    public String toString() {
        return "Date: " + date + "\nTitle: " + title + "\nContent: " + content + "\nIssuedBy: " + issuedBy;
    }
}
