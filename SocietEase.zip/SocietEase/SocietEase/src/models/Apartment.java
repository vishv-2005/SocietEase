package models;

public class Apartment {
    private String name;
    private String apartmentNumber;
    private String type;  // Owner, Tenant, or Empty
    private String helperID;

    public Apartment(String name, String apartmentNumber, String type, String helperID) {
        this.name = name;
        this.apartmentNumber = apartmentNumber;
        this.type = type;
        this.helperID = helperID;
    }

    public Apartment() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   //Getters and Setters 
    public String getName() {return name;}
    
    public void setName(String name) {this.name = name;}

    public String getApartmentNumber() {return apartmentNumber;}
    
    public void setApartmentNumber(String apartmentNumber) {this.apartmentNumber = apartmentNumber;}

    public String getType() {return type;}
    
    public void setType(String type) {this.type = type;}
    
    public String getHelperID() {return helperID;}
    
    public void setHelperID(String helperID) {this.helperID = helperID;}

    @Override
    public String toString() {
        return "Apartment Number : " + apartmentNumber +
               "\nType :  " + type +
               "\nName : " + name +
               "\n------------------";
    }

}
