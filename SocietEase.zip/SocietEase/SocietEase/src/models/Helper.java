package models;

public class Helper {
    private String helperID;
    private String name;
    private String role;
    private double salary;
    private String contactInfo;
    private long aadharNumber;

    public Helper(String helperID, String name, String role, double salary, String contactInfo, long aadharNumber) {
        
        this.helperID = helperID;
        this.name = name;
        this.role = role;
        this.salary = salary;
        this.contactInfo = contactInfo;
        this.aadharNumber = aadharNumber;
    }

    public Helper() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters
    public String getHelperID(){return helperID;}
    public String getName() { return name; }
    public String getRole() { return role; }
    public double getSalary() { return salary; }
    public String getContactInfo() { return contactInfo; }
    public long getAadharNumber() { return aadharNumber; }

   // Setters
    public void setHelperID(String helperID){ this.helperID = helperID ;}
    public void setName(String name) { this.name = name ; }
    public void setRole(String role) { this.role = role; }
    public void setSalary(double salary) { this.salary = salary; }
    public void setContactInfo(String contactInfo) { this.contactInfo = contactInfo; }
    public void setAadharNumber(long aadharNumber) { this.aadharNumber = aadharNumber; }

    @Override
    public String toString() {
        return "Helper [Name=" + name + ", Role=" + role + ", Salary=" + salary +
               ", Contact=" + contactInfo + ", Aadhar=" + aadharNumber + "]";
    }    
}
