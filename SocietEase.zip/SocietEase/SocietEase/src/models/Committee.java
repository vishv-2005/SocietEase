package models;

import java.util.List;

public class Committee {
    private String committeeID;
    private String name;
    private String head;
    private String apartmentNumber;
    private String description;

    public Committee(String committeeID, String name, String head, String apartmenetNumber, String description) {
        
        this.committeeID = committeeID;
        this.name = name;
        this.head = head;
        this.apartmentNumber = apartmenetNumber;
        this.description = description;
    }

    public Committee() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    //Gettters and Setters
    public String getCommitteeID() {
        return committeeID;
}

    public void setCommitteeID(String committeeID) {
        this.committeeID = committeeID;
}


    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getHead() {
        return head;
    }
    
    public void setHead(String head) {
        this.head = head;
    }
    
    public String getApartmentNumber() {
        return apartmentNumber;
    }
    
    public void setApartmentNumber(String apartmentNumber) {
        this.apartmentNumber = apartmentNumber;
    }

    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Committee Name: " + name +
               "\nHead: " + head +
                "\nApartment Number: " + apartmentNumber +
               "\nDescription: " + description +
               "\n---------------------------";
    }

}